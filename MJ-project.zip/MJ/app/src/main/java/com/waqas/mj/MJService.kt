package com.waqas.mj

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.Rect
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/** MJ ki aankhein aur haath: screen padhti hai, click/type/scroll karti hai. */
class MJService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: MJService? = null
    }

    private val nodes = mutableListOf<AccessibilityNodeInfo>()

    override fun onServiceConnected() {
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    /** Screen ki cheezon ki list banata hai: [id] text (click,edit,scroll) */
    fun dumpScreen(): String {
        nodes.clear()
        val root = rootInActiveWindow ?: return "(screen nahi padh saka)"
        val sb = StringBuilder("App: ${root.packageName}\n")

        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null) return
            val label = (n.text ?: n.contentDescription)?.toString()?.take(80)
            if (n.isVisibleToUser && (!label.isNullOrBlank() || n.isClickable || n.isEditable)) {
                nodes.add(n)
                val flags = buildList {
                    if (n.isClickable) add("click")
                    if (n.isEditable) add("edit")
                    if (n.isScrollable) add("scroll")
                }
                sb.append("[${nodes.size - 1}] ${label ?: ""} (${flags.joinToString(",")})\n")
            }
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(root)
        return sb.toString().take(6000)
    }

    fun click(id: Int): Boolean {
        val node = nodes.getOrNull(id) ?: return false
        var cur: AccessibilityNodeInfo? = node
        while (cur != null) {
            if (cur.isClickable) return cur.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            cur = cur.parent
        }
        val r = Rect()
        node.getBoundsInScreen(r)
        return tap(r.exactCenterX(), r.exactCenterY())
    }

    /** Seedha screen par us jagah tap (jab normal click asar na kare). */
    fun clickGesture(id: Int): Boolean {
        val node = nodes.getOrNull(id) ?: return false
        val r = Rect()
        node.getBoundsInScreen(r)
        return tap(r.exactCenterX(), r.exactCenterY())
    }

    fun type(id: Int, text: String): Boolean {
        val byId = nodes.getOrNull(id)?.takeIf { it.isEditable }
        val node = byId ?: rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return false
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        return node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    fun scroll(up: Boolean): Boolean {
        val node = nodes.firstOrNull { it.isScrollable } ?: return false
        val action = if (up) AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
        else AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
        return node.performAction(action)
    }

    private fun tap(x: Float, y: Float): Boolean {
        val path = Path().apply { moveTo(x, y) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 50))
            .build()
        return dispatchGesture(gesture, null, null)
    }
}
