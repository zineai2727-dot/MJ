package com.waqas.mj

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.Rect
import android.os.Build
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/** MJ ki aankhein aur haath: screen padhti hai, click, type, enter, scroll karti hai. */
class MJService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: MJService? = null
    }

    private val nodes = mutableListOf<AccessibilityNodeInfo>()

    override fun onServiceConnected() {
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    /** Screen ki cheezon ki list: [id] label (click, edit, scroll). Ye list AI ko jati hai. */
    fun dumpScreen(): String {
        nodes.clear()
        val root = rootInActiveWindow ?: return "(screen nahi padh saka)"
        val sb = StringBuilder("App: ${root.packageName}\n")
        walk(root, sb)
        return sb.toString().take(4000)
    }

    private fun walk(n: AccessibilityNodeInfo?, sb: StringBuilder) {
        if (n == null || nodes.size >= 150) return
        val label = (n.text ?: n.contentDescription)?.toString()?.trim()?.take(60).orEmpty()
        if (n.isVisibleToUser && (label.isNotBlank() || n.isClickable || n.isEditable)) {
            nodes.add(n)
            val flags = buildList {
                if (n.isClickable) add("click")
                if (n.isEditable) add("edit")
                if (n.isScrollable) add("scroll")
            }
            sb.append("[${nodes.size - 1}] $label (${flags.joinToString(",")})\n")
        }
        for (i in 0 until n.childCount) walk(n.getChild(i), sb)
    }

    /** Clickable hissa (ya uska parent) dabao. Kaam na kare to us jagah par tap. */
    fun click(id: Int): Boolean {
        val node = nodes.getOrNull(id) ?: return false
        var cur: AccessibilityNodeInfo? = node
        var depth = 0
        while (cur != null && depth < 6) {
            if (cur.isClickable && cur.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
            cur = cur.parent
            depth++
        }
        return tapCenter(node)
    }

    /** Seedha screen par us jagah tap (jab normal click kaam na kare). */
    fun clickGesture(id: Int): Boolean {
        val node = nodes.getOrNull(id) ?: return false
        return tapCenter(node)
    }

    private fun tapCenter(node: AccessibilityNodeInfo): Boolean {
        val r = Rect()
        node.getBoundsInScreen(r)
        return tap(r.exactCenterX(), r.exactCenterY())
    }

    /** Text likhna. id editable na ho to focus wala ya pehla editable box. */
    fun type(id: Int, text: String): Boolean {
        val target = nodes.getOrNull(id)?.takeIf { it.isEditable }
            ?: nodes.firstOrNull { it.isEditable && it.isFocused }
            ?: nodes.firstOrNull { it.isEditable }
            ?: return false
        target.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        return target.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    /** Keyboard par Enter / Search dabana (search box mein likhne ke baad). */
    fun enter(): Boolean {
        val focused = nodes.firstOrNull { it.isEditable && it.isFocused }
            ?: rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
            ?: return false
        return Build.VERSION.SDK_INT >= 30 &&
            focused.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)
    }

    fun scroll(up: Boolean): Boolean {
        val node = nodes.firstOrNull { it.isScrollable } ?: return false
        val action = if (up) AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
        else AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
        return node.performAction(action)
    }

    private fun tap(x: Float, y: Float): Boolean {
        val path = Path().apply { moveTo(x, y) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 60))
            .build()
        return dispatchGesture(gesture, null, null)
    }
}
