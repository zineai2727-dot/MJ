package com.waqas.mj

/** Service aur screen ke beech log ka chhota sa pul. */
object LogBus {
    private val lines = ArrayList<String>()

    @Volatile
    var listener: ((String) -> Unit)? = null

    @Synchronized
    fun log(line: String) {
        lines.add(line)
        if (lines.size > 200) lines.removeAt(0)
        listener?.invoke(line)
    }

    @Synchronized
    fun history(): List<String> = ArrayList(lines)
}
