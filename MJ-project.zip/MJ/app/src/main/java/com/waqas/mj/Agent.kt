package com.waqas.mj

import android.accessibilityservice.AccessibilityService
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONObject
import kotlin.coroutines.resume

/** Loop: screen dekho -> Gemini se poocho -> action karo -> dohrao jab tak kaam khatam. */
object Agent {

    interface Ui {
        fun log(line: String)
        fun say(text: String, onDone: () -> Unit)
        fun apiKey(): String
        fun onStarted()
        fun onFinished()
    }

    private const val MAX_STEPS = 12
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private var job: Job? = null

    @Volatile
    private var waiting: CompletableDeferred<String>? = null
    lateinit var ui: Ui

    fun isBusy(): Boolean = job?.isActive == true
    fun isWaiting(): Boolean = waiting != null

    /** User ka jawab (haan/nahi wagera) jab MJ ne sawal poochha ho. */
    fun answer(text: String) {
        val w = waiting ?: return
        waiting = null
        w.complete(text)
    }

    fun start(command: String) {
        if (isBusy()) return
        job = scope.launch {
            try {
                ui.onStarted()
                run(command)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                ui.log("Error: ${e.message}")
            } finally {
                ui.onFinished()
            }
        }
    }

    fun stop() {
        job?.cancel()
        waiting?.cancel()
        waiting = null
        ui.log("Kaam roak diya.")
    }

    private suspend fun say(text: String) = suspendCancellableCoroutine<Unit> { c ->
        ui.say(text) { if (c.isActive) c.resume(Unit) }
    }

    /** Sawal bolo, phir jawab ka intezar (20 second). */
    private suspend fun ask(question: String): String? {
        say(question)
        val d = CompletableDeferred<String>()
        waiting = d
        val reply = withTimeoutOrNull(20_000) { d.await() }
        waiting = null
        return reply
    }

    private suspend fun run(command: String) {
        ui.log("Aap: $command")
        val history = mutableListOf<String>()
        var lastKey = ""
        var sameCount = 0

        val first = MJService.instance
        if (first == null) {
            ui.log("Accessibility service ON karein.")
            say("पहले एक्सेसिबिलिटी सर्विस ऑन करें")
            return
        }
        // Chhote hukm (torch wagera) bina AI ke foran chalte hain.
        LocalIntents.tryHandle(first, first, command)?.let { local ->
            ui.log("MJ: ${local.third}  [local]")
            say(local.first)
            return
        }
        val apps = Phone.installedApps(first)

        repeat(MAX_STEPS) {
            val svc = MJService.instance ?: return
            val screen = svc.dumpScreen()

            val j: JSONObject = try {
                Brain.step(ui.apiKey(), command, history, screen, apps)
            } catch (e: Exception) {
                ui.log("Error: ${e.message}")
                say("माफ़ कीजिए बॉस, अभी नहीं हो पाया")
                return
            }

            val action = j.optString("action")
            val speech = j.optString("say")
            val show = j.optString("show").ifBlank { speech }
            ui.log("MJ: $show  [$action]")

            when (action) {
                "ask" -> {
                    val reply = ask(speech.ifBlank { show })
                    if (reply == null) {
                        say("कोई जवाब नहीं मिला बॉस")
                        return
                    }
                    ui.log("Aap: $reply")
                    history.add("MJ ne poocha: $show | User ne kaha: $reply")
                    return@repeat
                }
                "done" -> {
                    if (speech.isNotBlank()) say(speech)
                    return
                }
                "ignore" -> return
            }

            // Ek hi kaam baar baar ho to ruk jao.
            val key = "$action|${j.optInt("id", -1)}|${j.optString("text")}|${j.optString("arg")}"
            sameCount = if (key == lastKey) sameCount + 1 else 0
            lastKey = key
            if (sameCount >= 2) {
                ui.log("Ek hi kaam baar baar ho raha tha, ruk gayi.")
                say("यही काम बार बार हो रहा है, इसलिए मैं रुक गई")
                return
            }

            val ok = execute(svc, action, j)
            history.add("$action -> ${if (ok) "ho gaya" else "nakam"}")
            // Beech ke steps par bolna nahi rukta: fast rehne ke liye intezar nahi karte.
            if (speech.isNotBlank()) ui.say(speech) {}
            delay(600)
        }
        ui.log("Itne steps mein kaam mukammal nahi hua.")
    }

    private fun execute(svc: MJService, action: String, j: JSONObject): Boolean {
        val id = j.optInt("id", -1)
        val text = j.optString("text")
        val arg = j.optString("arg")
        return when (action) {
            "click" -> svc.click(id) || svc.clickGesture(id)
            "type" -> svc.type(id, text)
            "scroll" -> svc.scroll(arg == "up")
            "back" -> svc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK)
            "home" -> svc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_HOME)
            "open_app" -> Phone.openApp(svc, arg)
            "call" -> Phone.call(svc, arg)
            "torch" -> Phone.torch(svc, arg == "on")
            "volume" -> Phone.volume(svc, arg)
            "wait" -> true
            else -> false
        }
    }
}
