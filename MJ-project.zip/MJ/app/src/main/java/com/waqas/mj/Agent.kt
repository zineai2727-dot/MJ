package com.waqas.mj

import android.accessibilityservice.AccessibilityService
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONObject
import kotlin.coroutines.resume

/** Loop: screen dekho -> Gemini se poocho -> action karo -> dohrao jab tak kaam khatam. */
object Agent {

    interface Ui {
        fun log(line: String)
        fun say(text: String, onDone: () -> Unit)
        fun apiKey(): String
        fun onStarted()
        fun onFinished()
    }

    private const val MAX_STEPS = 15
    private val OPEN_WORDS = listOf("kholo", "khol", "kholen", "open", "chalao", "chalu karo")
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private var job: Job? = null

    @Volatile
    private var waiting: CompletableDeferred<String>? = null
    lateinit var ui: Ui

    fun isBusy(): Boolean = job?.isActive == true
    fun isWaiting(): Boolean = waiting != null

    /** User ka jawab, jab MJ ne sawal poochha ho. */
    fun answer(text: String) {
        val w = waiting ?: return
        waiting = null
        w.complete(text)
    }

    fun start(command: String) {
        if (isBusy()) return
        job = scope.launch {
            try {
                ui.onStarted()
                run(command)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                ui.log("Error: ${e.message}")
            } finally {
                ui.onFinished()
            }
        }
    }

    fun stop() {
        job?.cancel()
        waiting?.cancel()
        waiting = null
        ui.log("Kaam roak diya.")
    }

    private suspend fun say(text: String) = suspendCancellableCoroutine<Unit> { c ->
        ui.say(text) { if (c.isActive) c.resume(Unit) }
    }

    /** Sawal bolo, phir jawab ka intezar (20 second). */
    private suspend fun ask(question: String): String? {
        say(question)
        val d = CompletableDeferred<String>()
        waiting = d
        val reply = withTimeoutOrNull(20_000) { d.await() }
        waiting = null
        return reply
    }

    private suspend fun run(command: String) {
        ui.log("Aap: $command")
        val svc = MJService.instance
        if (svc == null) {
            ui.log("Accessibility service ON karein.")
            say("पहले एक्सेसिबिलिटी सर्विस ऑन करें")
            return
        }

        // 1) Chhote hukm bina AI ke (torch wagera): foran.
        LocalIntents.tryHandle(svc, svc, command)?.let { local ->
            ui.log("MJ: ${local.third}  [local]")
            say(local.first)
            return
        }

        // 2) App kholne ka hukm: app foran khol do, phir baqi hukm AI sambhale.
        val app = Phone.findAppIn(svc, command)
        val wantsOpen = OPEN_WORDS.any { command.lowercase().contains(it) }
        if (app != null && wantsOpen) {
            Phone.openApp(svc, app)
            ui.log("MJ: $app khol rahi hoon  [open_app]")
            delay(1500)
            val rest = command.lowercase()
                .replace(app.lowercase(), "")
                .split(Regex("\\s+"))
                .filter { it.isNotBlank() && it !in OPEN_WORDS && it.length > 1 }
            if (rest.isEmpty()) {
                say("जी बॉस, $app खोल दिया")
                return
            }
        }

        val apps = Phone.installedApps(svc)
        val history = mutableListOf<String>()
        var prevScreen = ""
        var prevKey = ""
        var sameCount = 0

        repeat(MAX_STEPS) {
            val cur = MJService.instance ?: return
            val screen = cur.dumpScreen()

            // Pichle action ke baad screen na badli ho to AI ko batao.
            if (prevKey.isNotEmpty() && screen == prevScreen) {
                history.add("NOTE: pichle action ke baad screen NAHI badli. Wahi action mat dohrao; doosra [id], enter, ya ask karo.")
            }

            val j: JSONObject = try {
                Brain.step(ui.apiKey(), command, history, screen, apps)
            } catch (e: Exception) {
                ui.log("Error: ${e.message}")
                say("माफ़ कीजिए बॉस, अभी नहीं हो पाया")
                return
            }

            val action = j.optString("action")
            val speech = j.optString("say")
            val show = j.optString("show").ifBlank { speech }
            ui.log("MJ: $show  [$action]")

            when (action) {
                "ask" -> {
                    val reply = ask(speech.ifBlank { show })
                    if (reply == null) {
                        say("कोई जवाब नहीं मिला बॉस")
                        return
                    }
                    ui.log("Aap: $reply")
                    history.add("MJ ne poocha: $show | User ne kaha: $reply")
                    prevKey = ""
                    return@repeat
                }
                "done" -> {
                    if (speech.isNotBlank()) say(speech)
                    return
                }
                "ignore" -> return
            }

            val id = j.optInt("id", -1)
            val text = j.optString("text")
            val arg = j.optString("arg")
            val key = "$action|$id|$text|$arg"
            sameCount = if (key == prevKey) sameCount + 1 else 0
            if (sameCount >= 2) {
                ui.log("Ek hi kaam baar baar ho raha tha, ruk gayi.")
                say("यही काम बार बार हो रहा है, इसलिए मैं रुक गई")
                return
            }

            // Dobara wahi click: is baar seedha tap try karo.
            val ok = execute(cur, action, id, text, arg, retry = sameCount == 1)
            history.add("$action id=$id text='$text' arg='$arg' -> ${if (ok) "ho gaya" else "nakam"}")

            prevKey = key
            prevScreen = screen
            // Tez rehne ke liye bolna intezar nahi karta.
            if (speech.isNotBlank()) ui.say(speech) {}
            delay(500)
        }
        ui.log("Itne steps mein kaam mukammal nahi hua.")
    }

    private suspend fun execute(svc: MJService, action: String, id: Int, text: String, arg: String, retry: Boolean): Boolean {
        return when (action) {
            "click" -> if (retry) svc.clickGesture(id) else svc.click(id)
            "type" -> svc.type(id, text)
            "enter" -> svc.enter()
            "scroll" -> svc.scroll(arg == "up")
            "back" -> svc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK)
            "home" -> svc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_HOME)
            "open_app" -> Phone.openApp(svc, arg)
            "call" -> Phone.call(svc, arg)
            "torch" -> Phone.torch(svc, arg == "on")
            "volume" -> Phone.volume(svc, arg)
            "wait" -> { delay(1000); true }
            else -> false
        }
    }
}
