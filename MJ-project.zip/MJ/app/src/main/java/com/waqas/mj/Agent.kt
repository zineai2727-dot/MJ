package com.waqas.mj

import android.accessibilityservice.AccessibilityService
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONObject
import kotlin.coroutines.resume

/** Loop: screen dekho -> Gemini se poocho -> action karo -> dohrao jab tak kaam khatam. */
object Agent {

    interface Ui {
        fun log(line: String)
        fun say(text: String, onDone: () -> Unit)
        fun apiKey(): String
        fun onStarted()
        fun onFinished()
    }

    private const val MAX_STEPS = 15
    private const val MAX_QUEUE = 6
    private val OPEN_WORDS = listOf("kholo", "khol", "kholen", "open", "chalao", "chalu karo")
    private val DONE_WORDS = listOf("haan", "ha ", "ho gaya", "ji", "جی", "ہاں", "ہو گیا", "हाँ", "हां", "हो गया", "yes")
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private val lock = Any()
    // Ek se zyada hukm aayen to line mein lagte hain, ek ek kar ke chalte hain.
    private val queue = ArrayDeque<String>()
    private var running = false
    private var job: Job? = null

    @Volatile
    private var waiting: CompletableDeferred<String>? = null
    lateinit var ui: Ui

    fun isBusy(): Boolean = synchronized(lock) { running }
    fun isWaiting(): Boolean = waiting != null

    /** User ka jawab, jab MJ ne sawal poochha ho. */
    fun answer(text: String) {
        val w = waiting ?: return
        waiting = null
        w.complete(text)
    }

    /** Hukm chalao. Agar kaam chal raha ho to hukm line mein lag jata hai. */
    fun start(command: String) {
        synchronized(lock) {
            if (running) {
                if (queue.size >= MAX_QUEUE) {
                    ui.log("Line bhari hai, ye hukm chhod diya: $command")
                } else {
                    queue.addLast(command)
                    ui.log("Line mein laga diya: $command")
                }
                return
            }
            running = true
        }
        job = scope.launch {
            ui.onStarted()
            var next: String? = command
            try {
                while (next != null) {
                    try {
                        run(next)
                    } catch (e: CancellationException) {
                        throw e
                    } catch (e: Exception) {
                        ui.log("Error: ${e.message}")
                    }
                    next = synchronized(lock) {
                        val n = queue.removeFirstOrNull()
                        if (n == null) running = false
                        n
                    }
                }
            } catch (e: CancellationException) {
                synchronized(lock) {
                    running = false
                    queue.clear()
                }
                throw e
            } finally {
                ui.onFinished()
            }
        }
    }

    fun stop() {
        synchronized(lock) { queue.clear() }
        job?.cancel()
        waiting?.cancel()
        waiting = null
        ui.log("Kaam roak diya.")
    }

    private suspend fun say(text: String) = suspendCancellableCoroutine<Unit> { c ->
        ui.say(text) { if (c.isActive) c.resume(Unit) }
    }

    /** Sawal bolo, phir jawab ka intezar (20 second). */
    private suspend fun ask(question: String): String? {
        say(question)
        val d = CompletableDeferred<String>()
        waiting = d
        val reply = withTimeoutOrNull(20_000) { d.await() }
        waiting = null
        return reply
    }

    /** Gemini se agla step. Net ya server ka masla ho to kuch dafa dobara koshish. */
    private suspend fun askBrain(command: String, history: List<String>, screen: String, apps: String): JSONObject? {
        for (attempt in 0 until 3) {
            try {
                return Brain.step(ui.apiKey(), command, history, screen, apps)
            } catch (e: Exception) {
                val err = e.message.orEmpty()
                ui.log("Error: $err")
                if (err.contains("free limit")) break
                delay(1500L * (attempt + 1))
            }
        }
        say("माफ़ कीजिए बॉस, अभी नहीं हो पाया")
        return null
    }

    private suspend fun run(command: String) {
        ui.log("Aap: $command")
        val svc = MJService.instance
        if (svc == null) {
            ui.log("Accessibility service ON karein.")
            say("पहले एक्सेसिबिलिटी सर्विस ऑन करें")
            return
        }

        // 1) Chhote hukm bina AI ke (torch wagera): foran.
        LocalIntents.tryHandle(svc, svc, command)?.let { local ->
            ui.log("MJ: ${local.third}  [local]")
            say(local.first)
            return
        }

        // 2) App kholne ka hukm: bolte hue app khol do, phir baqi hukm AI sambhale.
        val app = Phone.findAppIn(svc, command)
        val wantsOpen = OPEN_WORDS.any { command.lowercase().contains(it) }
        if (app != null && wantsOpen) {
            ui.say("जी बॉस, $app खोल रही हूँ") {}
            Phone.openApp(svc, app)
            ui.log("MJ: $app khol rahi hoon  [open_app]")
            delay(1500)
            val rest = command.lowercase()
                .replace(app.lowercase(), "")
                .split(Regex("\\s+"))
                .filter { it.isNotBlank() && it !in OPEN_WORDS && it.length > 1 }
            if (rest.isEmpty()) return
        }

        val apps = Phone.installedApps(svc)
        val history = mutableListOf<String>()
        var prevScreen = ""
        var prevKey = ""
        var unchanged = 0
        var skips = 0
        var waits = 0
        val recentKeys = mutableListOf<String>()

        repeat(MAX_STEPS) {
            val cur = MJService.instance ?: return
            val screen = cur.dumpScreen()

            // Pichle action ke baad screen na badli ho to AI ko batao.
            if (prevKey.isNotEmpty() && screen == prevScreen) {
                history.add("NOTE: pichle action ke baad screen NAHI badli. Wahi action mat dohrao; doosra [id], enter, ya ask karo.")
            }

            val j: JSONObject = askBrain(command, history, screen, apps) ?: return

            val action = j.optString("action")
            val speech = j.optString("say")
            val show = j.optString("show").ifBlank { speech }
            ui.log("MJ: $show  [$action]")

            when (action) {
                "ask" -> {
                    val reply = ask(speech.ifBlank { show })
                    if (reply == null) {
                        say("कोई जवाब नहीं मिला बॉस")
                        return
                    }
                    ui.log("Aap: $reply")
                    history.add("MJ ne poocha: $show | User ne kaha: $reply")
                    prevKey = ""
                    return@repeat
                }
                "done" -> {
                    if (speech.isNotBlank()) say(speech)
                    return
                }
                "ignore" -> return
            }

            // Kai steps se screen nahi badli: user se poochho ke kaam ho gaya ya nahi.
            unchanged = if (prevKey.isNotEmpty() && screen == prevScreen) unchanged + 1 else 0
            if (unchanged >= 3) {
                val r = ask("बॉस, हो गया या आगे क्या करूँ?") ?: return
                ui.log("Aap: $r")
                if (DONE_WORDS.any { r.lowercase().contains(it) }) {
                    say("ठीक है बॉस")
                    return
                }
                history.add("User ne kaha: $r")
                unchanged = 0
                prevKey = ""
                return@repeat
            }

            val id = j.optInt("id", -1)
            val text = j.optString("text")
            val arg = j.optString("arg")
            val key = "$action|$id|$text|$arg"
            // Wahi kaam pichle 3 qadmon mein ho chuka: dobara nahi karna.
            if (action != "scroll" && action != "wait" && recentKeys.takeLast(3).contains(key)) {
                ui.log("Ye kaam abhi ho chuka hai, dobara nahi kiya.")
                history.add("NOTE: '$action' yahi kaam abhi ho chuka hai. Dobara mat karo; agla qadam socho ya done karo.")
                skips++
                if (skips >= 3) {
                    ui.log("Ek hi kaam baar baar ho raha tha, ruk gayi.")
                    say("यही काम बार बार हो रहा है, इसलिए मैं रुक गई")
                    return
                }
                prevScreen = screen
                return@repeat
            }
            recentKeys.add(key)

            // "wait" bar bar aaye to ruk jao, screen khud load ho jati hai ya user ko batao.
            if (action == "wait") {
                waits++
                if (waits >= 3) {
                    ui.log("Intezar bahut ho gaya, ruk gayi.")
                    say("थोड़ी देर बाद फिर कोशिश करती हूँ बॉस")
                    return
                }
            } else {
                waits = 0
            }

            // Awaaz aur kaam ek sath: bolna shuru, usi waqt kaam.
            if (speech.isNotBlank()) ui.say(speech) {}

            // Screen na badli ho to ek dafa seedha tap try karo.
            val ok = execute(cur, action, id, text, arg, retry = prevKey.isNotEmpty() && screen == prevScreen)
            history.add("$action id=$id text='$text' arg='$arg' -> ${if (ok) "ho gaya" else "nakam"}")

            prevKey = key
            prevScreen = screen
            delay(500)
        }
        ui.log("Itne steps mein kaam mukammal nahi hua.")
    }

    private suspend fun execute(svc: MJService, action: String, id: Int, text: String, arg: String, retry: Boolean): Boolean {
        return when (action) {
            "click" -> if (retry) svc.clickGesture(id) else svc.click(id)
            "long" -> svc.longClick(id)
            "type" -> svc.type(id, text)
            "enter" -> svc.enter()
            "scroll" -> svc.scroll(arg == "up")
            "back" -> svc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK)
            "home" -> svc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_HOME)
            "open_app" -> Phone.openApp(svc, arg)
            "call" -> Phone.call(svc, arg)
            "torch" -> Phone.torch(svc, arg == "on")
            "volume" -> Phone.volume(svc, arg)
            "wait" -> { delay(1000); true }
            else -> false
        }
    }
}
