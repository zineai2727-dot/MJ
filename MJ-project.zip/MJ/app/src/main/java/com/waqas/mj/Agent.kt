package com.waqas.mj

import android.accessibilityservice.AccessibilityService
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeoutOrNull
import kotlin.coroutines.resume

/** Loop: screen dekho -> AI se poocho -> action karo -> dohrao jab tak "done". */
object Agent {

    interface Ui {
        fun log(line: String)
        fun speak(hindi: String, urdu: String, onDone: () -> Unit)
        fun listen()
        fun apiKey(): String
        fun speakNow(hindi: String, urdu: String)
        fun appContext(): android.content.Context
        fun onStarted()
        fun onFinished()
    }

    fun isBusy(): Boolean = job?.isActive == true
    fun isWaiting(): Boolean = waiting != null

    private const val MAX_STEPS = 15
    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())
    private var job: Job? = null

    @Volatile
    private var waiting: CompletableDeferred<String>? = null
    lateinit var ui: Ui

    /** Voice se jo bhi suna jaye, yahan aata hai. */
    fun onHeard(text: String) {
        val w = waiting
        if (w != null) {
            waiting = null
            w.complete(text)
            return
        }
        job?.cancel()
        job = scope.launch {
            try {
                ui.onStarted()
                run(text)
            } finally {
                ui.onFinished()
            }
        }
    }

    fun stop() {
        job?.cancel()
        waiting?.cancel()
        waiting = null
        ui.log("MJ ruk gayi.")
    }

    private suspend fun say(hindi: String, urdu: String = hindi) = suspendCancellableCoroutine<Unit> { c ->
        ui.speak(hindi, urdu) { if (c.isActive) c.resume(Unit) }
    }

    private suspend fun waitForReply(): String {
        val d = CompletableDeferred<String>()
        waiting = d
        ui.listen()
        val reply = withTimeoutOrNull(25_000) { d.await() }
        waiting = null
        return reply ?: "(koi jawab nahi mila)"
    }

    private suspend fun run(command: String) {
        ui.log("Aap: $command")

        // Chhote seedhe kaam (torch, awaaz, back, home) bina AI ke: foran aur free.
        val local = LocalIntents.tryHandle(ui.appContext(), MJService.instance, command)
        if (local != null) {
            ui.log("MJ: ${local.third}")
            ui.speakNow(local.first, local.second)
            return
        }
        ui.speakNow("जी बॉस", "جی باس") // foran jawab, taake lage MJ sun rahi hai
        val log = mutableListOf<String>()
        val apps = MJService.instance?.let { Phone.installedApps(it) } ?: ""

        var prevScreen = ""
        var prevKey = ""
        var prevWasUi = false
        var sameCount = 0

        repeat(MAX_STEPS) {
            val svc = MJService.instance
            if (svc == null) {
                ui.log("Pehle Accessibility Service on karo.")
                say("पहले एक्सेसिबिलिटी सर्विस ऑन करें", "پہلے ایکسیسبیلٹی سروس آن کریں")
                return
            }

            val screen = svc.dumpScreen()
            val unchanged = prevWasUi && screen == prevScreen
            if (unchanged) {
                log.add("NOTE: pichle action ke baad screen NAHI badli. Wahi action dohrao mat; koi doosra [id], scroll ya alag tareeqa try karo.")
            }
            val j = try {
                Brain.step(ui.apiKey(), command, log, screen, apps)
            } catch (e: Brain.QuotaException) {
                ui.log("Error: ${e.message}")
                say("बॉस, आज की फ्री लिमिट खत्म हो गई है", "باس، آج کی فری لمٹ ختم ہو گئی ہے")
                return
            } catch (e: Exception) {
                ui.log("Error: ${e.message?.take(300)}")
                return
            }

            val action = j.optString("action")
            val id = j.optInt("id", -1)
            val text = j.optString("text")
            val arg = j.optString("arg")
            val key = "$action|$id|$text|$arg"
            if (key == prevKey) sameCount++ else sameCount = 0
            if (sameCount >= 2 && action != "ask" && action != "done") {
                ui.log("MJ: Ek hi kaam baar baar ho raha hai, is liye ruk gayi.")
                say("यही काम बार बार हो रहा है, इसलिए मैं रुक गई", "یہی کام بار بار ہو رہا ہے، اس لیے میں رک گئی")
                return
            }
            ui.log("MJ: ${j.optString("say_roman")}  [$action]")

            val urdu = j.optString("say_hindi").ifBlank { j.optString("say_roman") }
            val urduScript = j.optString("say_urdu").ifBlank { urdu }

            when (action) {
                "ask" -> {
                    say(urdu, urduScript)
                    val reply = waitForReply()
                    ui.log("Aap: $reply")
                    log.add("MJ ne poocha: ${j.optString("say_roman")} | User ne kaha: $reply")
                    return@repeat
                }
                "done" -> {
                    ui.speakNow(urdu, urduScript)
                    return
                }
                "ignore" -> return // shor ya doosron ki baatein: chup raho
            }

            // Beech ke steps par sirf likhti hai, bolti nahi (har bolna ek API call hai aur reply late karta hai).
            // Mukammal hone par ("done") pyar se bolti hai.

            val ok: Boolean = when (action) {
                "click" -> if (unchanged && key == prevKey) svc.clickGesture(id) else svc.click(id)
                "type" -> svc.type(id, text)
                "scroll" -> svc.scroll(arg == "up")
                "back" -> svc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK)
                "home" -> svc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_HOME)
                "open_app" -> Phone.openApp(svc, arg)
                "call" -> Phone.call(svc, arg)
                "torch" -> Phone.torch(svc, arg == "on")
                "volume" -> Phone.volume(svc, arg)
                "wait" -> true
                else -> false
            }
            log.add("$action id=$id text='$text' arg='$arg' -> ${if (ok) "ho gaya" else "nakam"}")
            // Beech ke steps par bolna band: bolne ka intezar hi sab se bada slowdown tha.
            delay(700) // screen ko settle hone do
            prevScreen = screen
            prevKey = key
            prevWasUi = action in setOf("click", "type", "scroll", "back", "home")
        }
        ui.log("Itne steps mein kaam mukammal nahi hua, ruk gayi.")
    }
}
