package com.waqas.mj

import android.accessibilityservice.AccessibilityService
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeoutOrNull
import kotlin.coroutines.resume

/** Loop: screen dekho -> AI se poocho -> action karo -> dohrao jab tak "done". */
object Agent {

    interface Ui {
        fun log(line: String)
        fun speak(urdu: String, onDone: () -> Unit)
        fun listen()
        fun apiKey(): String
    }

    private const val MAX_STEPS = 15
    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())
    private var job: Job? = null

    @Volatile
    private var waiting: CompletableDeferred<String>? = null
    lateinit var ui: Ui

    /** Voice se jo bhi suna jaye, yahan aata hai. */
    fun onHeard(text: String) {
        val w = waiting
        if (w != null) {
            waiting = null
            w.complete(text)
            return
        }
        job?.cancel()
        job = scope.launch { run(text) }
    }

    fun stop() {
        job?.cancel()
        waiting?.cancel()
        waiting = null
        ui.log("MJ ruk gayi.")
    }

    private suspend fun say(urdu: String) = suspendCancellableCoroutine<Unit> { c ->
        ui.speak(urdu) { if (c.isActive) c.resume(Unit) }
    }

    private suspend fun waitForReply(): String {
        val d = CompletableDeferred<String>()
        waiting = d
        ui.listen()
        val reply = withTimeoutOrNull(25_000) { d.await() }
        waiting = null
        return reply ?: "(koi jawab nahi mila)"
    }

    private suspend fun run(command: String) {
        ui.log("Aap: $command")
        val log = mutableListOf<String>()

        repeat(MAX_STEPS) {
            val svc = MJService.instance
            if (svc == null) {
                ui.log("Pehle Accessibility Service on karo.")
                say("پہلے ایکسیسبیلٹی سروس آن کریں")
                return
            }

            val screen = svc.dumpScreen()
            val j = try {
                Brain.step(ui.apiKey(), command, log, screen)
            } catch (e: Exception) {
                ui.log("Error: ${e.message}")
                return
            }

            val action = j.optString("action")
            val id = j.optInt("id", -1)
            val text = j.optString("text")
            val arg = j.optString("arg")
            ui.log("MJ: ${j.optString("say_roman")}  [$action]")

            val urdu = j.optString("say_urdu")

            when (action) {
                "ask" -> {
                    say(urdu)
                    val reply = waitForReply()
                    ui.log("Aap: $reply")
                    log.add("MJ ne poocha: ${j.optString("say_roman")} | User ne kaha: $reply")
                    return@repeat
                }
                "done" -> {
                    say(urdu)
                    return
                }
            }

            val ok: Boolean = when (action) {
                "click" -> svc.click(id)
                "type" -> svc.type(id, text)
                "scroll" -> svc.scroll(arg == "up")
                "back" -> svc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK)
                "home" -> svc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_HOME)
                "open_app" -> Phone.openApp(svc, arg)
                "call" -> Phone.call(svc, arg)
                "torch" -> Phone.torch(svc, arg == "on")
                "volume" -> Phone.volume(svc, arg)
                "wait" -> true
                else -> false
            }
            log.add("$action id=$id text='$text' arg='$arg' -> ${if (ok) "ho gaya" else "nakam"}")
            say(urdu)
            delay(1200) // screen ko settle hone do
        }
        ui.log("Itne steps mein kaam mukammal nahi hua, ruk gayi.")
    }
}
