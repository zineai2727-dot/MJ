package com.waqas.mj

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper

/**
 * MJ ka background hissa.
 *
 * Do tareeqe:
 *  - "Hamesha MJ sunna" BAND (default): mic band rehta hai. Notification mein "Bolo" dabao,
 *    MJ jagti hai, 10 second sunti hai, phir mic band.
 *  - "Hamesha MJ sunna" ON: "MJ" bolne par jagti hai (mic baar baar on-off ho sakta hai).
 *
 * Jagne ke baad "MJ" kahe baghair hukm do. Aap 10 second kuch na bolo to MJ so jati hai.
 */
class ListenService : Service(), Agent.Ui {

    companion object {
        @Volatile
        var running = false

        const val ACTION_TALK = "mj.TALK"
        const val ACTION_STOP_TASK = "mj.STOP_TASK"
        const val ACTION_NEXT_VOICE = "mj.NEXT_VOICE"
        const val ACTION_QUIT = "mj.QUIT"
        const val ACTION_APPLY = "mj.APPLY"

        private const val CHANNEL = "mj_listen"
        private const val NOTIF_ID = 1

        private const val ACTIVE_MS = 10_000L    // bolna band hone ke baad itni der jagi rehti hai
        private const val DEBOUNCE_MS = 1_500L   // bolna rukne ke baad itna intezar, phir kaam shuru

        // "MJ", "एमजे", "एमजी", "ایم جے" wagera (voice se alag alag likha aata hai)
        private val WAKE = Regex(
            """(?i)(\bm\s?j\b|\bm\s?g\b|\bem\s?j(ay|i)\b|एम\s?जे|एम\s?जी|ایم\s?جے|ایم\s?جی|ام\s?جے|ام\s?جی)"""
        )
    }

    private enum class Mode { IDLE, ACTIVE }

    private val main = Handler(Looper.getMainLooper())
    private lateinit var voice: Voice
    private var mode = Mode.IDLE
    private val buffer = mutableListOf<String>()
    private val prefs by lazy { getSharedPreferences("mj", MODE_PRIVATE) }

    private fun wakeAlways() = prefs.getBoolean("wake_always", false)

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        running = true
        startAsForeground()
        voice = Voice(this, { onSpeech(it) }, { LogBus.log(it) })
        voice.geminiKey = geminiKey()
        voice.prewarm(listOf("جی باس", "جی باس؟"))
        Agent.ui = this
        if (wakeAlways()) {
            voice.startContinuous()
            LogBus.log("MJ chalu hai. \"MJ\" bol kar hukm do.")
        } else {
            LogBus.log("MJ chalu hai. Bolne ke liye notification mein \"Bolo\" dabao ya app ka \"MJ se abhi bolo\" button.")
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_TALK -> {
                activate()
                say("जी बॉस?", "جی باس؟")
            }
            ACTION_STOP_TASK -> Agent.stop()
            ACTION_NEXT_VOICE -> voice.nextVoice()
            ACTION_APPLY -> {
                if (wakeAlways()) voice.startContinuous()
                else if (mode == Mode.IDLE) voice.stopContinuous()
            }
            ACTION_QUIT -> stopSelf()
        }
        return START_STICKY
    }

    override fun onDestroy() {
        running = false
        main.removeCallbacksAndMessages(null)
        voice.shutdown()
        super.onDestroy()
    }

    // ---------- Notification (zaroori, warna Android background mic band kar deta hai) ----------
    private fun action(code: Int, label: String, act: String): Notification.Action {
        val pi = PendingIntent.getService(
            this, code, Intent(this, ListenService::class.java).setAction(act), PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Action.Builder(android.R.drawable.ic_btn_speak_now, label, pi).build()
    }

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "MJ", NotificationManager.IMPORTANCE_LOW)
        )
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, CHANNEL)
            .setContentTitle("MJ chalu hai")
            .setContentText("Bolne ke liye \"Bolo\" dabao")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(open)
            .addAction(action(1, "Bolo", ACTION_TALK))
            .addAction(action(2, "Roko", ACTION_STOP_TASK))
            .addAction(action(3, "Band", ACTION_QUIT))
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    // ---------- Jo suna uska faisla ----------
    private fun onSpeech(text: String) {
        // MJ ne kuch poocha hai to jawab seedha usse do.
        if (Agent.isWaiting()) {
            Agent.onHeard(text)
            voice.setSuspended(true)
            return
        }
        // Kaam chal raha ho to mic band hai; agar kuch aa jaye to nazar andaaz.
        if (Agent.isBusy()) return

        val wake = WAKE.find(text)
        var cmd = text
        if (mode == Mode.IDLE) {
            if (wake == null) return // ye MJ ke liye nahi tha
            cmd = text.removeRange(wake.range).trim()
            LogBus.log("MJ jag gayi.")
            if (cmd.isBlank()) say("जी बॉस?", "جی باس؟")
        } else if (wake != null) {
            cmd = text.removeRange(wake.range).trim()
        }

        activate()
        if (cmd.isNotBlank()) {
            buffer.add(cmd)
            // Aap thori der ruk kar kuch aur bolo to wo isi hukm mein jur jayega.
            main.removeCallbacks(dispatch)
            main.postDelayed(dispatch, DEBOUNCE_MS)
        }
    }

    private val dispatch = Runnable {
        if (buffer.isEmpty()) return@Runnable
        val cmd = buffer.joinToString(" ").trim()
        buffer.clear()
        if (cmd.isNotBlank()) Agent.onHeard(cmd)
    }

    /** Jaga do aur 10 second ka sone ka timer dobara shuru karo. */
    private fun activate() {
        mode = Mode.ACTIVE
        voice.startContinuous()
        main.removeCallbacks(goIdle)
        main.postDelayed(goIdle, ACTIVE_MS)
    }

    private val goIdle = Runnable { checkIdle() }

    private fun checkIdle() {
        if (Agent.isBusy() || Agent.isWaiting() || buffer.isNotEmpty()) {
            main.postDelayed(goIdle, 3_000L)
            return
        }
        mode = Mode.IDLE
        if (wakeAlways()) {
            LogBus.log("MJ so gayi. Jagane ke liye \"MJ\" bolo.")
        } else {
            voice.stopContinuous()
            LogBus.log("MJ so gayi (mic band). Jagane ke liye \"Bolo\" dabao.")
        }
    }

    /** MJ ke bolne ke baad sone ka 10 second ka timer dobara shuru. */
    private fun afterSpeech() {
        main.post { if (mode == Mode.ACTIVE && !Agent.isBusy()) activate() }
    }

    // ---------- Agent.Ui ----------
    override fun log(line: String) = LogBus.log(line)

    /** Gemini ki awaaz (Sulafat) agar chalu ho, warna Android awaaz. */
    private fun geminiKey(): String {
        if (!prefs.getBoolean("gemini_voice", true)) return ""
        val tts = prefs.getString("tts_key", "").orEmpty().trim()
        if (tts.isNotEmpty()) return tts
        val k = apiKey()
        return if (k.startsWith("gsk_")) "" else k // Groq key se Gemini awaaz nahi banti
    }

    private fun say(hindi: String, urdu: String) {
        voice.geminiKey = geminiKey()
        voice.speak(hindi, rich = urdu)
    }

    override fun speak(hindi: String, urdu: String, onDone: () -> Unit) {
        main.post {
            voice.geminiKey = geminiKey()
            voice.speak(hindi, rich = urdu) {
                onDone()
                afterSpeech()
            }
        }
    }

    override fun speakNow(hindi: String, urdu: String) {
        main.post {
            voice.geminiKey = geminiKey()
            voice.speak(hindi, flush = true, rich = urdu) { afterSpeech() }
        }
    }

    override fun listen() {
        // MJ ne sawal poocha hai: jawab sunne ke liye mic dobara chalu.
        main.post { voice.setSuspended(false) }
    }

    override fun apiKey(): String = prefs.getString("key", "").orEmpty()

    override fun appContext(): android.content.Context = applicationContext

    override fun onStarted() {
        // Kaam chal raha ho to mic band, taake jhatke na lagein aur MJ apni awaaz na sune.
        main.post {
            buffer.clear()
            voice.setSuspended(true)
        }
    }

    override fun onFinished() {
        main.post {
            voice.setSuspended(false)
            activate()
        }
    }
}
