package com.waqas.mj

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper

/**
 * MJ ka session. Button se shuru hota hai.
 * Jagi hui: hukm sunti hai aur kaam karti hai. 10 second kuch na ho to so jaati hai.
 * Soi hui: sirf wake word ("एमजे") sunti hai, aur jagati hai. Mic on/off nahi hota, Vosk offline sunta hai.
 */
class ListenService : Service(), Agent.Ui {

    companion object {
        @Volatile
        var running = false

        const val ACTION_STOP_TASK = "mj.STOP_TASK"
        const val ACTION_QUIT = "mj.QUIT"
        const val ACTION_TEXT = "mj.TEXT"
        const val EXTRA_TEXT = "text"

        private const val CHANNEL = "mj_listen"
        private const val NOTIF_ID = 1
        private const val IDLE_MS = 10_000L
        private const val DUP_MS = 4_000L
        // Vosk Hindi likhta hai (Devanagari). Space hata kar milate hain.
        private val WAKE = listOf("एमजे", "एमजी")
        private val STOP_WORDS = listOf("रुको", "रुक जाओ", "बंद करो", "ruko", "band karo", "stop")
    }

    private val main = Handler(Looper.getMainLooper())
    private lateinit var voice: Voice
    private lateinit var ears: Ears

    private var awake = false
    private var lastCmd = ""
    private var lastCmdAt = 0L

    private val idleRunnable = Runnable { checkIdle() }
    private val resumeRunnable = Runnable { ears.setPaused(false) }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        running = true
        startAsForeground()
        voice = Voice(
            this,
            onInfo = { LogBus.log(it) },
            onSpeaking = { speaking ->
                main.post {
                    main.removeCallbacks(resumeRunnable)
                    if (speaking) ears.setPaused(true)
                    else main.postDelayed(resumeRunnable, 600)
                }
            }
        )
        ears = Ears(this, onText = { onHeard(it) }, onInfo = { LogBus.log(it) })
        Agent.ui = this
        LogBus.log("Model load ho raha hai, thora intezar karo...")
        ears.load {
            ears.start()
            LogBus.log("MJ taiyaar hai. Hukm do boss.")
        }
        awake = true
        touch()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP_TASK -> Agent.stop()
            ACTION_QUIT -> stopSelf()
            ACTION_TEXT -> intent.getStringExtra(EXTRA_TEXT)?.let { typed(it) }
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        running = false
        main.removeCallbacksAndMessages(null)
        ears.stop()
        voice.shutdown()
        super.onDestroy()
    }

    // ---------- Notification (zaroori, warna Android background mein mic band kar deta hai) ----------
    private fun action(code: Int, label: String, act: String): Notification.Action {
        val pi = PendingIntent.getService(
            this, code, Intent(this, ListenService::class.java).setAction(act), PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Action.Builder(android.R.drawable.ic_menu_close_clear_cancel, label, pi).build()
    }

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "MJ", NotificationManager.IMPORTANCE_LOW))
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, CHANNEL)
            .setContentTitle("MJ sun rahi hai")
            .setContentText("\"एमजे\" bolo ya hukm do")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(open)
            .addAction(action(2, "Roko", ACTION_STOP_TASK))
            .addAction(action(3, "Band", ACTION_QUIT))
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    // ---------- Jo suna uska faisla ----------
    private fun onHeard(raw: String) {
        val text = raw.trim()
        if (text.length < 2) return
        if (!awake) {
            // Soi hui: sirf wake word par jago.
            val norm = text.replace(" ", "")
            if (WAKE.none { norm.contains(it) }) return
            awake = true
            LogBus.log("MJ jaag gayi.")
            val rest = WAKE.fold(text) { acc, w -> acc.replace(w, "", ignoreCase = true) }
                .replace(Regex("\\s+"), " ").trim()
            touch()
            if (rest.length < 2) {
                voice.say("जी बॉस")
            } else {
                handleCommand(rest)
            }
            return
        }
        touch()
        val lower = text.lowercase()
        if (STOP_WORDS.any { lower.contains(it) }) {
            if (Agent.isBusy()) Agent.stop()
            return
        }
        handleCommand(text)
    }

    /** Likha hua hukm (Devanagari / Roman sab chalega). */
    private fun typed(raw: String) {
        val text = raw.trim()
        if (text.isEmpty()) return
        awake = true
        touch()
        handleCommand(text)
    }

    private fun handleCommand(text: String) {
        val now = System.currentTimeMillis()
        val lower = text.lowercase()
        // Ek hi hukm thori dair mein dobara aaye to chhod do.
        if (lower == lastCmd && now - lastCmdAt < DUP_MS) return
        lastCmd = lower
        lastCmdAt = now
        if (Agent.isWaiting()) {
            Agent.answer(text)
            return
        }
        // Kaam chal raha ho to hukm line mein lag jata hai (Agent khud sambhalta hai).
        Agent.start(text)
    }

    /** Har asli hukm par 10 second ka timer dobara shuru. */
    private fun touch() {
        main.removeCallbacks(idleRunnable)
        main.postDelayed(idleRunnable, IDLE_MS)
    }

    private fun checkIdle() {
        if (Agent.isBusy() || Agent.isWaiting()) {
            touch()
            return
        }
        if (awake) {
            awake = false
            LogBus.log("MJ so gayi. \"एमजे\" bolo ya button dabao.")
        }
    }

    // ---------- Agent.Ui ----------
    override fun log(line: String) = LogBus.log(line)

    override fun say(text: String, onDone: () -> Unit) {
        main.post { voice.say(text, onDone = onDone) }
    }

    override fun apiKey(): String =
        getSharedPreferences("mj", MODE_PRIVATE).getString("key", "").orEmpty()

    override fun onStarted() {
        main.post { touch() }
    }

    override fun onFinished() {
        main.post { touch() }
    }
}
