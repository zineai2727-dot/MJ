package com.waqas.mj

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper

/**
 * MJ ka background hissa: hamesha sunti hai, "MJ" sunte hi jagti hai,
 * hukm ka intezar karti hai (beech ki khamoshi bardasht karti hai) aur Agent ko deti hai.
 */
class ListenService : Service(), Agent.Ui {

    companion object {
        @Volatile
        var running = false

        const val ACTION_TALK = "mj.TALK"
        const val ACTION_STOP_TASK = "mj.STOP_TASK"
        const val ACTION_NEXT_VOICE = "mj.NEXT_VOICE"
        const val ACTION_QUIT = "mj.QUIT"

        private const val CHANNEL = "mj_listen"
        private const val NOTIF_ID = 1

        private const val ACTIVE_MS = 10_000L    // "MJ" ke baad hukm shuru karne ke liye
        private const val FOLLOWUP_MS = 7_000L   // kaam ke baad bina "MJ" bole agla hukm
        private const val DEBOUNCE_MS = 1_500L   // bolna rukne ke baad itna intezar, phir kaam shuru

        // "MJ", "एमजे", "एमजी", "ایم جے" wagera (voice se alag alag likha aata hai)
        private val WAKE = Regex(
            """(?i)(\bm\s?j\b|\bm\s?g\b|\bem\s?j(ay|i)\b|एम\s?जे|एम\s?जी|ایم\s?جے|ایم\s?جی|ام\s?جے|ام\s?جی)"""
        )
        private val STOP = Regex(
            """(?i)(रुको|ठहरो|बंद\s?करो|ruko|\bstop\b|band\s?karo|روکو|رک\s?جاؤ|بند\s?کرو)"""
        )
    }

    private enum class Mode { IDLE, ACTIVE }

    private val main = Handler(Looper.getMainLooper())
    private lateinit var voice: Voice
    private var mode = Mode.IDLE
    private val buffer = mutableListOf<String>()
    private val prefs by lazy { getSharedPreferences("mj", MODE_PRIVATE) }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        running = true
        startAsForeground()
        voice = Voice(this, { onSpeech(it) }, { LogBus.log(it) })
        Agent.ui = this
        voice.startContinuous()
        LogBus.log("MJ chalu hai. \"MJ\" bol kar hukm do, jaise: MJ torch on karo.")
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_TALK -> {
                activate(ACTIVE_MS)
                voice.speak("जी?")
            }
            ACTION_STOP_TASK -> Agent.stop()
            ACTION_NEXT_VOICE -> voice.nextVoice()
            ACTION_QUIT -> stopSelf()
        }
        return START_STICKY
    }

    override fun onDestroy() {
        running = false
        main.removeCallbacksAndMessages(null)
        voice.shutdown()
        super.onDestroy()
    }

    // ---------- Notification (zaroori, warna Android background mic band kar deta hai) ----------
    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "MJ sun rahi hai", NotificationManager.IMPORTANCE_LOW)
        )
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val quit = PendingIntent.getService(
            this, 1, Intent(this, ListenService::class.java).setAction(ACTION_QUIT), PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, CHANNEL)
            .setContentTitle("MJ chalu hai")
            .setContentText("\"MJ\" bol kar hukm do")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(open)
            .addAction(Notification.Action.Builder(android.R.drawable.ic_menu_close_clear_cancel, "Band karo", quit).build())
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    // ---------- Jo suna uska faisla ----------
    private fun onSpeech(text: String) {
        // MJ ne kuch poocha hai to jawab seedha usse do.
        if (Agent.isWaiting()) {
            Agent.onHeard(text)
            return
        }
        // Kaam chal raha ho to sirf "ruko" jaisa hukm suno.
        if (Agent.isBusy()) {
            if (STOP.containsMatchIn(text)) Agent.stop()
            return
        }

        val wake = WAKE.find(text)
        var cmd = text
        if (mode == Mode.IDLE) {
            if (wake == null) return // ye MJ ke liye nahi tha, nazar andaaz
            cmd = text.removeRange(wake.range).trim()
            LogBus.log("MJ jag gayi.")
            if (cmd.isBlank()) voice.speak("जी?")
        } else if (wake != null) {
            cmd = text.removeRange(wake.range).trim()
        }

        activate(ACTIVE_MS)
        if (cmd.isNotBlank()) {
            buffer.add(cmd)
            // Agar aap thori der ruk kar kuch aur bolo to wo isi hukm mein jur jayega.
            main.removeCallbacks(dispatch)
            main.postDelayed(dispatch, DEBOUNCE_MS)
        }
    }

    private val dispatch = Runnable {
        if (buffer.isEmpty()) return@Runnable
        val cmd = buffer.joinToString(" ").trim()
        buffer.clear()
        if (cmd.isNotBlank()) Agent.onHeard(cmd)
    }

    private fun activate(ms: Long) {
        mode = Mode.ACTIVE
        main.removeCallbacks(goIdle)
        main.postDelayed(goIdle, ms)
    }

    private val goIdle = Runnable { checkIdle() }

    private fun checkIdle() {
        if (Agent.isBusy() || Agent.isWaiting() || buffer.isNotEmpty()) {
            main.postDelayed({ checkIdle() }, 3_000L)
            return
        }
        mode = Mode.IDLE
        LogBus.log("MJ so gayi. Jagane ke liye \"MJ\" bolo.")
    }

    // ---------- Agent.Ui ----------
    override fun log(line: String) = LogBus.log(line)

    override fun speak(urdu: String, onDone: () -> Unit) {
        main.post { voice.speak(urdu, onDone) }
    }

    override fun listen() {
        // Hamesha sun rahi hai, is liye kuch karne ki zaroorat nahi.
    }

    override fun apiKey(): String = prefs.getString("key", "").orEmpty()

    override fun onFinished() {
        // Kaam ke baad kuch der bina "MJ" bole agla hukm sun lo.
        main.post { activate(FOLLOWUP_MS) }
    }
}
