package com.waqas.mj

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper

/**
 * MJ ka session. Button se shuru hota hai. Hukm sunti hai, kaam karti hai.
 * 10 second kuch na ho to khamosh ho kar band ho jati hai. Dobara button se chalti hai.
 * Wake word nahi hai.
 */
class ListenService : Service(), Agent.Ui {

    companion object {
        @Volatile
        var running = false

        const val ACTION_STOP_TASK = "mj.STOP_TASK"
        const val ACTION_QUIT = "mj.QUIT"

        private const val CHANNEL = "mj_listen"
        private const val NOTIF_ID = 1
        private const val IDLE_MS = 10_000L
        private val STOP_WORDS = listOf("ruko", "band karo", "stop", "رکو", "روکو", "रुको", "रुक जाओ")
    }

    private val main = Handler(Looper.getMainLooper())
    private lateinit var voice: Voice
    private val prefs by lazy { getSharedPreferences("mj", MODE_PRIVATE) }

    private val idleRunnable = Runnable { checkIdle() }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        running = true
        startAsForeground()
        voice = Voice(this, { onSpeech(it) }, { LogBus.log(it) })
        Agent.ui = this
        voice.startContinuous()
        LogBus.log("MJ jagi hai. Hukm do boss.")
        touch()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP_TASK -> Agent.stop()
            ACTION_QUIT -> stopSelf()
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        running = false
        main.removeCallbacksAndMessages(null)
        voice.shutdown()
        super.onDestroy()
    }

    // ---------- Notification (zaroori, warna Android background mein mic band kar deta hai) ----------
    private fun action(code: Int, label: String, act: String): Notification.Action {
        val pi = PendingIntent.getService(
            this, code, Intent(this, ListenService::class.java).setAction(act), PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Action.Builder(android.R.drawable.ic_menu_close_clear_cancel, label, pi).build()
    }

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "MJ", NotificationManager.IMPORTANCE_LOW))
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, CHANNEL)
            .setContentTitle("MJ sun rahi hai")
            .setContentText("Hukm do boss")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(open)
            .addAction(action(2, "Roko", ACTION_STOP_TASK))
            .addAction(action(3, "Band", ACTION_QUIT))
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    // ---------- Jo suna uska faisla ----------
    private fun onSpeech(text: String) {
        touch()
        // MJ ne sawal poocha hai to ye jawab hai.
        if (Agent.isWaiting()) {
            Agent.answer(text)
            return
        }
        val lower = text.lowercase()
        if (Agent.isBusy()) {
            if (STOP_WORDS.any { lower.contains(it) }) Agent.stop()
            return
        }
        Agent.start(text)
    }

    /** Har activity par 10 second ka sone ka timer dobara shuru. */
    private fun touch() {
        main.removeCallbacks(idleRunnable)
        main.postDelayed(idleRunnable, IDLE_MS)
    }

    private fun checkIdle() {
        if (Agent.isBusy() || Agent.isWaiting()) {
            touch()
            return
        }
        LogBus.log("MJ so gayi. Dobara jagane ke liye button dabao.")
        stopSelf()
    }

    // ---------- Agent.Ui ----------
    override fun log(line: String) = LogBus.log(line)

    override fun say(text: String, onDone: () -> Unit) {
        main.post { voice.say(text, onDone = onDone) }
    }

    override fun apiKey(): String = prefs.getString("key", "").orEmpty()

    override fun onStarted() {
        main.post { touch() }
    }

    override fun onFinished() {
        main.post { touch() }
    }
}
