package com.waqas.mj

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper

/**
 * MJ ka background hissa. "MJ" sunte hi jagti hai, hukm leti hai, kaam karti hai,
 * phir kuch der baad khamosh (so) ho jati hai.
 */
class ListenService : Service(), Agent.Ui {

    companion object {
        @Volatile
        var running = false

        const val ACTION_STOP_TASK = "mj.STOP_TASK"
        const val ACTION_QUIT = "mj.QUIT"

        private const val CHANNEL = "mj_listen"
        private const val NOTIF_ID = 1
        private const val AWAKE_MS = 10_000L   // "MJ" ke baad itni der jagi rahegi
        private const val DEBOUNCE_MS = 1_200L // bolna rukne ke baad itna intezar, phir kaam shuru

        // "MJ" ke alag-alag talaffuz (English, Devanagari, Urdu)
        private val WAKE = Regex(
            """(?i)(\bm\s?j\b|\bem\s?j(ay|i)\b|एम\s?जे|एम\s?जी|ایم\s?جے|ایم\s?جی|ام\s?جے|ام\s?جی)"""
        )
    }

    private val main = Handler(Looper.getMainLooper())
    private lateinit var voice: Voice
    private var active = false
    private val buffer = mutableListOf<String>()
    private val prefs by lazy { getSharedPreferences("mj", MODE_PRIVATE) }

    private val dispatchRunnable = Runnable {
        val cmd = buffer.joinToString(" ").trim()
        buffer.clear()
        if (cmd.isNotBlank()) Agent.start(cmd)
    }
    private val sleepRunnable = Runnable { checkSleep() }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        running = true
        startAsForeground()
        voice = Voice(this, { onSpeech(it) }, { LogBus.log(it) })
        Agent.ui = this
        voice.startContinuous()
        LogBus.log("MJ taiyar hai. \"MJ\" bol kar hukm do.")
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP_TASK -> Agent.stop()
            ACTION_QUIT -> stopSelf()
        }
        return START_STICKY
    }

    override fun onDestroy() {
        running = false
        main.removeCallbacksAndMessages(null)
        voice.shutdown()
        super.onDestroy()
    }

    // ---------- Notification (zaroori, warna Android background mein mic band kar deta hai) ----------
    private fun action(code: Int, label: String, act: String): Notification.Action {
        val pi = PendingIntent.getService(
            this, code, Intent(this, ListenService::class.java).setAction(act), PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Action.Builder(android.R.drawable.ic_menu_close_clear_cancel, label, pi).build()
    }

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "MJ", NotificationManager.IMPORTANCE_LOW))
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, CHANNEL)
            .setContentTitle("MJ chalu hai")
            .setContentText("\"MJ\" bol kar hukm do")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(open)
            .addAction(action(2, "Roko", ACTION_STOP_TASK))
            .addAction(action(3, "Band", ACTION_QUIT))
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    // ---------- Jo suna uska faisla ----------
    private fun onSpeech(text: String) {
        // MJ ne sawal poocha hai to ye jawab hai.
        if (Agent.isWaiting()) {
            touch()
            Agent.answer(text)
            return
        }
        // Kaam chal raha hai: nayi baat ab nahi sunenge.
        if (Agent.isBusy()) return

        val wake = WAKE.find(text)
        if (wake != null) {
            val cmd = text.removeRange(wake.range).trim()
            wake()
            if (cmd.isBlank()) voice.say("जी बॉस?", flush = true) else queue(cmd)
            return
        }
        // Jaag rahi ho to "MJ" ke baghair bhi hukm mana jayega.
        if (active) queue(text)
    }

    private fun wake() {
        if (!active) LogBus.log("MJ jag gayi.")
        active = true
        touch()
    }

    private fun queue(cmd: String) {
        buffer.add(cmd)
        main.removeCallbacks(dispatchRunnable)
        main.postDelayed(dispatchRunnable, DEBOUNCE_MS)
        touch()
    }

    /** Har activity par sone ka timer dobara shuru. */
    private fun touch() {
        main.removeCallbacks(sleepRunnable)
        main.postDelayed(sleepRunnable, AWAKE_MS)
    }

    private fun checkSleep() {
        if (Agent.isBusy() || Agent.isWaiting() || buffer.isNotEmpty()) {
            touch()
            return
        }
        if (active) {
            active = false
            LogBus.log("MJ so gayi. \"MJ\" bol kar jagao.")
        }
    }

    // ---------- Agent.Ui ----------
    override fun log(line: String) = LogBus.log(line)

    override fun say(text: String, onDone: () -> Unit) {
        main.post { voice.say(text, onDone = onDone) }
    }

    override fun apiKey(): String = prefs.getString("key", "").orEmpty()

    override fun onStarted() {
        main.post {
            buffer.clear()
            touch()
        }
    }

    override fun onFinished() {
        main.post { touch() }
    }
}
