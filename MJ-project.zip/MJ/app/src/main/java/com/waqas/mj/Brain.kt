package com.waqas.mj

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/** MJ ka dimagh: Gemini (flash-lite) ko screen aur hukm bhejta hai, jawab mein ek action aata hai. */
object Brain {

    const val MODEL = "gemini-flash-lite-latest"

    private val client = OkHttpClient.Builder()
        .callTimeout(40, TimeUnit.SECONDS)
        .build()

    private val SYSTEM = """
        Tum MJ ho, Android phone ki female assistant. User ko "बॉस" kehna. Tum tez, shaista aur madadgar ho.
        Har jawab SIRF ek JSON object ho, aur kuch nahi:
        {"say":"...","show":"...","action":"...","id":0,"text":"...","arg":"..."}

        say: boli jane wali ek chhoti line, Devanagari mein Urdu alfaaz (jaise "जी बॉस, यूट्यूब खोल रही हूँ"). Max 8 alfaaz. English alfaaz nahi (YouTube ko "यूट्यूब" likho).
        show: wahi line Roman Urdu mein.

        action ki qismein:
        - click: screen ki list ka [id] dabao
        - type: text likho (text do; id do agar pata ho)
        - scroll: arg = "up" ya "down"
        - back, home
        - open_app: arg = PHONE KE APPS ki list se bilkul wahi naam
        - call: arg = contact ka naam ya number
        - torch: arg = "on" ya "off"
        - volume: arg = "up", "down", "max" ya "mute"
        - wait: thora intezar
        - ask: user se sawal (say mein sawal). Jawab agle step mein milega.
        - done: kaam mukammal (say mein chhota ikrar)
        - ignore: hukm samajh na aaye ya phone se mutalliq na ho

        Qaide:
        1. Message bhejne, call karne, delete karne ya kisi bhi paise wale kaam se PEHLE ZAROOR action "ask" karo (jaise "बॉस, मैसेज भेज दूँ?"). Jawab "haan" ho tabhi aage barho.
        2. Password, OTP, bank ya card ki screen par kuch na likho aur na dabao.
        3. Ek step mein ek action. Jo kaam ho chuka usay dobara na karo.
        4. Spelling mein bataye naam ko PHONE KE APPS ki list se milao aur open_app karo, type mat karo.
        5. Har step ka nateeja "AB TAK KA KAAM" mein hai. Agar pichla action kaam na kar paya, to alag tareeqa ya ask karo.
        6. Jo hukm phone ka nahi ya adhoora hai, us par ignore karo.
    """.trimIndent()

    /** Ek step ka action. history: ab tak ke kaam ki lines. */
    fun step(apiKey: String, command: String, history: List<String>, screen: String, apps: String): JSONObject {
        if (apiKey.isBlank()) throw RuntimeException("Pehle upar API key likho.")

        val done = if (history.isEmpty()) "(abhi kuch nahi)" else history.takeLast(12).joinToString("\n")
        val msg = "HUKM: $command\n\nPHONE KE APPS: $apps\n\nAB TAK KA KAAM:\n$done\n\nSCREEN:\n$screen"

        var last = ""
        for (attempt in 0 until 3) {
            val (code, raw) = post(apiKey, msg)
            if (code in 200..299) return parse(raw)
            last = "API error $code: $raw"
            if (code == 429) throw RuntimeException("Gemini ki free limit aaj ke liye khatam hai. Kal dobara try karo ya billing on karo.")
            if (code != 503 && code != 500) throw RuntimeException(last)
            Thread.sleep(1500L * (attempt + 1))
        }
        throw RuntimeException("Google abhi masroof hai. Thori der baad try karo.\n$last")
    }

    private fun post(apiKey: String, msg: String): Pair<Int, String> {
        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", SYSTEM))))
            .put(
                "contents",
                JSONArray().put(
                    JSONObject().put("role", "user")
                        .put("parts", JSONArray().put(JSONObject().put("text", msg)))
                )
            )
            .put(
                "generationConfig",
                JSONObject()
                    .put("responseMimeType", "application/json")
                    .put("maxOutputTokens", 700)
                    .put("temperature", 0.3)
            )

        val req = Request.Builder()
            .url("https://generativelanguage.googleapis.com/v1beta/models/$MODEL:generateContent")
            .header("x-goog-api-key", apiKey)
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .build()

        return try {
            client.newCall(req).execute().use { r -> Pair(r.code, r.body?.string().orEmpty()) }
        } catch (e: java.io.IOException) {
            Pair(503, "Internet ka masla: ${e.message}")
        }
    }

    private fun parse(raw: String): JSONObject {
        val text = JSONObject(raw).getJSONArray("candidates").getJSONObject(0)
            .getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
        val s = text.indexOf('{')
        val e = text.lastIndexOf('}')
        if (s < 0 || e < s) throw RuntimeException("AI ne JSON nahi diya: $text")
        return JSONObject(text.substring(s, e + 1))
    }
}
