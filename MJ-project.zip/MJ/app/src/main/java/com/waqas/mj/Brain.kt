package com.waqas.mj

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/** MJ ka dimagh: Gemini ko screen aur hukm bhejta hai, jawab mein ek action aata hai. */
object Brain {

    // Pehla model tez hai. Masroof ho to doosra.
    private val MODELS = listOf("gemini-flash-lite-latest", "gemini-flash-latest")

    private val client = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(25, TimeUnit.SECONDS)
        .callTimeout(35, TimeUnit.SECONDS)
        .build()

    private val SYSTEM = """
        Tum MJ ho: Android phone ki tez, shaista, female assistant. User ko "बॉस" kehna.
        Har jawab SIRF ek JSON object ho, aur kuch nahi:
        {"say":"...","show":"...","action":"...","id":0,"text":"...","arg":"..."}

        say: boli jane wali ek chhoti line, Devanagari mein Urdu alfaaz (jaise "जी बॉस, व्हाट्सएप खोल रही हूँ"). Max 8 alfaaz. English alfaaz nahi (WhatsApp ko "व्हाट्सएप", YouTube ko "यूट्यूब" likho).
        show: wahi line Roman Urdu mein.

        Actions:
        - click: screen list ka [id] dabao
        - type: text likho (text do). Pehle search/message box par click karna zaroori ho to pehle click karo.
        - enter: keyboard par Search/Enter dabao. Search likhne ke FORAN baad ye zaroor karo, dobara type mat karo.
        - long: lamba dabao (message ko delete/copy karne ke liye)
        - scroll: arg = "up" ya "down"
        - back, home
        - open_app: arg = PHONE KE APPS list ka bilkul wahi naam
        - call: arg = contact ka naam ya number (sirf tab jab user ne call kaha ho aur tasdeeq ho)
        - torch: arg = "on" ya "off"
        - volume: arg = "up", "down", "max", "mute"
        - wait: 1 second intezar (screen load ho rahi ho)
        - ask: user se chhota sawal (say mein sawal). Jawab agle step mein milega.
        - done: kaam mukammal (say mein chhota ikrar)
        - ignore: hukm phone ka nahi ya samajh na aaye

        Tarike (flows):
        - "X ki chat kholo" (WhatsApp): agar WhatsApp khula nahi to open_app WhatsApp. Phir search icon (desc "Search") click, X likho, enter, phir X ke naam wali row par click (profile photo/DP par NAHI). Chat khul jaye to ask karo: "boss, call karun, message likhun, ya voice note?"
        - Agar user ne chat ka naam nahi bataya: ask karo "kis ki chat kholun boss?"
        - Message: ask karo ke kya likhun. Phir message box (edit) mein type, phir ask karo "bhej doon boss?". "haan" ke baad Send (desc "Send") click.
        - Call: "Voice call" ya "Call" icon click. Pehle ask karo agar tasdeeq nahi.
        - YouTube par gaana/video: search icon click, text type, enter. Phir search results mein wo item chuno jiska label lamba video dikhata hai (time jaise "4:12" wala, ya "Video"), aur jis mein "Shorts" na ho. "Long video" kaha ho to Shorts bilkul mat chuno. Video play ho jaye (player dikhe) to foran done karo, Shorts ya agli video par kabhi click mat karo.
        - Message delete: message ko long action se dabao, phir "Delete" click, phir ask karo "delete for everyone ya sirf mere liye?" aur user ke kehne par wahi option click karo. Delete ho gaya (message gayab) to foran done karo.
        - Har kaam ke baad screen dekho: agar kaam pura ho gaya hai (message gayab, video chal rahi, chat khuli) to turant done. Dobara click mat karo.
        - Kisi bhi app mein kaam ho to sirf usi app mein raho.

        Qaide:
        1. Message bhejne, call karne, delete karne ya paisay se mutalliq kaam se PEHLE ask karo.
        2. Password, OTP, bank ya card ki screen par kuch na likho aur na dabao.
        3. Sirf wahi karo jo user ne kaha. Ek step mein ek action.
        4. DP, profile photo, status, ads, notification aur settings par click mat karo jab tak na kaha ho.
        5. "AB TAK KA KAAM" dekho. Agar NOTE likha ho ke screen NAHI badli, to wahi action dobara na karo: doosra [id], enter, ya ask karo.
        6. Ek hi cheez 2 baar se zyada na karo.
        7. Kaam khatam ho to done. Jo na ho saka, usay sach bata kar done karo.
        9. Jo kaam user ne kaha wohi karo. Shorts, recommendations ya doosri cheezon par khud se click mat karo.
        8. PHONE KE APPS ki list se hi app ka naam lo.
    """.trimIndent()

    /** Ek step ka action. history = ab tak ke kaam ki lines. */
    fun step(apiKey: String, command: String, history: List<String>, screen: String, apps: String): JSONObject {
        if (apiKey.isBlank()) throw RuntimeException("Pehle upar API key likho.")

        val done = if (history.isEmpty()) "(abhi kuch nahi)" else history.takeLast(10).joinToString("\n")
        val msg = "HUKM: $command\n\nPHONE KE APPS: $apps\n\nAB TAK KA KAAM:\n$done\n\nSCREEN:\n$screen"

        var last = ""
        for (model in MODELS) {
            for (attempt in 0 until 2) {
                val (code, raw) = post(model, apiKey, msg)
                if (code in 200..299) return parse(raw)
                last = "API error $code: $raw"
                if (code == 429) throw RuntimeException("Gemini ki free limit aaj ke liye khatam hai. Kal try karo ya billing on karo.")
                if (code == 599) break // internet ya timeout: foran agla model
                if (code != 503 && code != 500 && code != 404) throw RuntimeException(last)
                if (code == 404) break // ye model band hai, agla model
                Thread.sleep(1000L * (attempt + 1))
            }
        }
        throw RuntimeException("Google abhi masroof hai. Thori der baad try karo.\n$last")
    }

    private fun post(model: String, apiKey: String, msg: String): Pair<Int, String> {
        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", SYSTEM))))
            .put(
                "contents",
                JSONArray().put(
                    JSONObject().put("role", "user")
                        .put("parts", JSONArray().put(JSONObject().put("text", msg)))
                )
            )
            .put(
                "generationConfig",
                JSONObject()
                    .put("responseMimeType", "application/json")
                    .put("maxOutputTokens", 500)
                    .put("temperature", 0.2)
            )

        val req = Request.Builder()
            .url("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
            .header("x-goog-api-key", apiKey)
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .build()

        return try {
            client.newCall(req).execute().use { r -> Pair(r.code, r.body?.string().orEmpty()) }
        } catch (e: java.io.IOException) {
            Pair(599, "Internet ka masla: ${e.message}")
        }
    }

    private fun parse(raw: String): JSONObject {
        val text = JSONObject(raw).getJSONArray("candidates").getJSONObject(0)
            .getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
        val s = text.indexOf('{')
        val e = text.lastIndexOf('}')
        if (s < 0 || e < s) throw RuntimeException("AI ne JSON nahi diya: $text")
        return JSONObject(text.substring(s, e + 1))
    }
}
