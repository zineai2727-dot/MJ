package com.waqas.mj

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/** MJ ka dimagh: screen + hukm Google Gemini API ko bhejta hai, jawab mein ek JSON action aata hai. */
object Brain {
    // Pehla model pehle try hota hai. Wo masroof (503) ya band (404) ho to agla try hota hai.
    // Naam badalne hon to Google AI Studio mein models ki list dekho.
    val MODELS = listOf("gemini-flash-lite-latest", "gemini-flash-latest")

    private val client = OkHttpClient.Builder()
        .callTimeout(60, TimeUnit.SECONDS)
        .build()

    private val SYSTEM = """
        Tum MJ ho, ek female voice assistant jo Android phone control karti hai.
        User Urdu, Roman Urdu ya Hindi mein bolta hai. Tum hamesha Urdu mein jawab deti ho, English nahi.
        Har step par SIRF ek JSON object do, aur kuch nahi:
        {"say_urdu":"...","say_roman":"...","action":"...","id":0,"text":"...","arg":"..."}

        say_urdu: chhota sa jumla Urdu script mein, female andaaz mein (jaise "ji, main kar rahi hoon").
        say_roman: wohi jumla Roman Urdu mein.

        action ki qismein:
        - click: screen list ka [id] dabao (id do)
        - type: text likho (text do, id do agar maloom ho)
        - scroll: arg = "up" ya "down"
        - back, home
        - open_app: arg = app ka naam (jaise "WhatsApp")
        - call: arg = contact ka naam ya number
        - torch: arg = "on" ya "off"
        - volume: arg = "up", "down", "max" ya "mute"
        - wait: thora intezar
        - ask: user se sawal ya confirmation poochna (say_urdu mein sawal)
        - done: kaam mukammal

        Qaide:
        1. Message SEND karne, call karne, kuch delete karne ya paisay se mutalliq koi bhi kaam se PEHLE action "ask" se confirmation lo.
        2. Password, OTP, bank ya card ki maloomat kabhi na likho, na bhejo.
        3. Sirf wahi karo jo user ne kaha. Ek step mein ek hi action.
        4. Screen ki list mein har cheez [id] ke saath hai. Agar screen par wo cheez nahi jo chahiye, scroll ya back karo.
        5. Kaam ho jaye to action "done" aur say_urdu mein mukhtasar khabar.
    """.trimIndent()

    private class Result(val json: JSONObject?, val code: Int, val error: String)

    fun step(apiKey: String, command: String, log: List<String>, screen: String): JSONObject {
        if (apiKey.isBlank()) throw RuntimeException("Pehle upar wale box mein API key likho.")

        val done = if (log.isEmpty()) "(abhi kuch nahi)" else log.joinToString("\n")
        val userMsg = "HUKM: $command\n\nAB TAK KE KAAM:\n$done\n\nSCREEN:\n$screen"

        var lastError = ""
        for (attempt in 0 until 4) {
            for (model in MODELS) {
                val r = callOnce(model, apiKey, userMsg)
                if (r.json != null) return r.json
                lastError = r.error
                // 503 = server masroof, 429 = limit, 404 = model band: agla model / dobara koshish.
                // Baqi errors (galat key wagera) foran dikha do.
                if (r.code != 503 && r.code != 429 && r.code != 404) throw RuntimeException(r.error)
            }
            Thread.sleep(2000L * (attempt + 1))
        }
        throw RuntimeException("Google ke servers abhi masroof hain. Thori der baad dobara bolo.\n$lastError")
    }

    private fun callOnce(model: String, apiKey: String, userMsg: String): Result {
        val gen = JSONObject()
            .put("responseMimeType", "application/json")
            .put("maxOutputTokens", 600)
            .put("temperature", 0.2)
        // 2.5 Flash mein "sochne" ka hissa band, taake jawab tez aaye.
        if (model.contains("2.5-flash")) {
            gen.put("thinkingConfig", JSONObject().put("thinkingBudget", 0))
        }

        val body = JSONObject()
            .put(
                "systemInstruction",
                JSONObject().put("parts", JSONArray().put(JSONObject().put("text", SYSTEM)))
            )
            .put(
                "contents",
                JSONArray().put(
                    JSONObject()
                        .put("role", "user")
                        .put("parts", JSONArray().put(JSONObject().put("text", userMsg)))
                )
            )
            .put("generationConfig", gen)

        val req = Request.Builder()
            .url("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
            .header("x-goog-api-key", apiKey)
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .build()

        return try {
            client.newCall(req).execute().use { resp ->
                val raw = resp.body?.string().orEmpty()
                if (!resp.isSuccessful) return Result(null, resp.code, "API error ${resp.code}: $raw")
                val text = JSONObject(raw)
                    .getJSONArray("candidates").getJSONObject(0)
                    .getJSONObject("content").getJSONArray("parts")
                    .getJSONObject(0).getString("text")
                val s = text.indexOf('{')
                val e = text.lastIndexOf('}')
                if (s < 0 || e < s) return Result(null, 0, "AI ne JSON nahi diya: $text")
                Result(JSONObject(text.substring(s, e + 1)), 200, "")
            }
        } catch (e: java.io.IOException) {
            // Internet ka masla: dobara koshish ke liye 503 jaisa treat karo.
            Result(null, 503, "Internet ka masla: ${e.message}")
        }
    }
}
