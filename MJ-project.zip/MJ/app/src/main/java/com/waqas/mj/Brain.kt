package com.waqas.mj

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/** MJ ka dimagh: screen + hukm Claude API ko bhejta hai, jawab mein ek JSON action aata hai. */
object Brain {
    // Model badalna ho to sirf yahan badlo.
    const val MODEL = "claude-sonnet-5-5"

    private val client = OkHttpClient.Builder()
        .callTimeout(60, TimeUnit.SECONDS)
        .build()

    private val SYSTEM = """
        Tum MJ ho, ek female voice assistant jo Android phone control karti hai.
        User Urdu, Roman Urdu ya Hindi mein bolta hai. Tum hamesha Urdu mein jawab deti ho, English nahi.
        Har step par SIRF ek JSON object do, aur kuch nahi:
        {"say_urdu":"...","say_roman":"...","action":"...","id":0,"text":"...","arg":"..."}

        say_urdu: chhota sa jumla Urdu script mein, female andaaz mein (jaise "ji, main kar rahi hoon").
        say_roman: wohi jumla Roman Urdu mein.

        action ki qismein:
        - click: screen list ka [id] dabao (id do)
        - type: text likho (text do, id do agar maloom ho)
        - scroll: arg = "up" ya "down"
        - back, home
        - open_app: arg = app ka naam (jaise "WhatsApp")
        - call: arg = contact ka naam ya number
        - torch: arg = "on" ya "off"
        - volume: arg = "up", "down", "max" ya "mute"
        - wait: thora intezar
        - ask: user se sawal ya confirmation poochna (say_urdu mein sawal)
        - done: kaam mukammal

        Qaide:
        1. Message SEND karne, call karne, kuch delete karne ya paisay se mutalliq koi bhi kaam se PEHLE action "ask" se confirmation lo.
        2. Password, OTP, bank ya card ki maloomat kabhi na likho, na bhejo.
        3. Sirf wahi karo jo user ne kaha. Ek step mein ek hi action.
        4. Screen ki list mein har cheez [id] ke saath hai. Agar screen par wo cheez nahi jo chahiye, scroll ya back karo.
        5. Kaam ho jaye to action "done" aur say_urdu mein mukhtasar khabar.
    """.trimIndent()

    fun step(apiKey: String, command: String, log: List<String>, screen: String): JSONObject {
        val done = if (log.isEmpty()) "(abhi kuch nahi)" else log.joinToString("\n")
        val userMsg = "HUKM: $command\n\nAB TAK KE KAAM:\n$done\n\nSCREEN:\n$screen"

        val body = JSONObject()
            .put("model", MODEL)
            .put("max_tokens", 500)
            .put("system", SYSTEM)
            .put(
                "messages",
                JSONArray().put(JSONObject().put("role", "user").put("content", userMsg))
            )

        val req = Request.Builder()
            .url("https://api.anthropic.com/v1/messages")
            .header("x-api-key", apiKey)
            .header("anthropic-version", "2023-06-01")
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .build()

        client.newCall(req).execute().use { resp ->
            val raw = resp.body?.string().orEmpty()
            if (!resp.isSuccessful) throw RuntimeException("API error ${resp.code}: $raw")
            val text = JSONObject(raw).getJSONArray("content").getJSONObject(0).getString("text")
            val s = text.indexOf('{')
            val e = text.lastIndexOf('}')
            if (s < 0 || e < s) throw RuntimeException("AI ne JSON nahi diya: $text")
            return JSONObject(text.substring(s, e + 1))
        }
    }
}
