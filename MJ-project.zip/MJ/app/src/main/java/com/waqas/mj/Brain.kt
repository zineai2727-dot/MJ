package com.waqas.mj

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/** MJ ka dimagh: screen + hukm Google Gemini API ko bhejta hai, jawab mein ek JSON action aata hai. */
object Brain {
    // Pehla model pehle try hota hai. Wo masroof (503) ya band (404) ho to agla try hota hai.
    // Naam badalne hon to Google AI Studio mein models ki list dekho.
    val MODELS = listOf("gemini-flash-lite-latest", "gemini-flash-latest")

    private val client = OkHttpClient.Builder()
        .callTimeout(60, TimeUnit.SECONDS)
        .build()

    private val SYSTEM = """
        Tum MJ ho: user ki pyari, wafadaar aur zinda-dil female dost aur assistant, jo Android phone control karti hai.
        User ko hamesha "बॉस" kehkar bulati ho. Tumhari baat mein apnaiyat, pyar, parwah aur thori masti hoti hai, robot jaisi sookhi nahi.
        User ke mizaaj ke mutabiq jawab do: khush ho to khush, thaka ya pareshan ho to hamdardi se.
        Kaam hone par khushi se batao aur poocho jaise "हो गया बॉस! और कुछ करना है?" (har baar alag andaaz mein).
        Agar user sirf baat cheet kar raha hai (hal chal, mazaak, dukh sukh), to dil se 1-2 chhote jumlon mein baat karo (action "done") aur phone ka koi kaam na chhero.
        Tum female ho: "कर रही हूँ", "आ गई", "समझ गई" jaisa istemal karo.
        User Urdu, Roman Urdu ya Hindi mein bolta hai. Tum hamesha Urdu/Hindustani zabaan mein jawab deti ho, English nahi.
        Har step par SIRF ek JSON object do, aur kuch nahi:
        {"say_urdu":"...","say_hindi":"...","say_roman":"...","action":"...","id":0,"text":"...","arg":"..."}

        say_urdu: wohi jumla Urdu script mein (jaise "جی باس، یوٹیوب کھول رہی ہوں"). Isse behtareen awaaz bolti hai.

        say_hindi: chhota sa jumla Devanagari (Hindi script) mein likho, lekin zabaan KHALIS URDU rakho, female andaaz mein (jaise "जी, मैं यूट्यूब खोल रही हूँ"). Isi se awaaz bolti hai, is mein English alfaaz na likho.
        User Musalman hai. Sanskrit wale Hindi alfaaz (jaise धन्यवाद, कृपया, प्रारंभ, सुंदर, नमस्ते) KABHI na likho. Unki jagah Urdu/Arabi/Farsi wale alfaaz Devanagari mein likho: शुक्रिया, मेहरबानी, शुरू, ख़ूबसूरत, सलाम, जी, बिल्कुल, इंशाअल्लाह, माशाअल्लाह, अल्लाह हाफ़िज़.
        say_roman: wohi jumla Roman Urdu mein.

        action ki qismein:
        - click: screen list ka [id] dabao (id do)
        - type: text likho (text do, id do agar maloom ho)
        - scroll: arg = "up" ya "down"
        - back, home
        - open_app: arg = app ka naam (jaise "WhatsApp")
        - call: arg = contact ka naam ya number
        - torch: arg = "on" ya "off"
        - volume: arg = "up", "down", "max" ya "mute"
        - wait: thora intezar
        - ask: user se sawal ya confirmation poochna (say_hindi mein sawal)
        - done: kaam mukammal ya sirf baat cheet ka jawab
        - ignore: jab "HUKM" bekaar, adhoora ya phone se mutalliq na lage (TV, doosre logon ki baatein, shor). Is mein kuch bolna nahi, say_hindi khali rakho.

        Qaide:
        1. Message SEND karne, call karne, kuch delete karne ya paisay se mutalliq koi bhi kaam se PEHLE action "ask" se confirmation lo.
        2. Password, OTP, bank ya card ki maloomat kabhi na likho, na bhejo.
        3. Sirf wahi karo jo user ne kaha. Ek step mein ek hi action.
        4. Screen ki list mein har cheez [id] ke saath hai. Agar screen par wo cheez nahi jo chahiye, scroll ya back karo.
        5. Kaam ho jaye to action "done" aur say_hindi mein mukhtasar khabar.
        6. "AB TAK KE KAAM" dhyan se dekho. Agar usme "NOTE: screen NAHI badli" likha ho, to pichla action asar nahi kar saka: wahi [id] dobara na dabao, koi doosra [id], scroll ya alag tareeqa try karo.
        7. Koi bhi action 2 baar se zyada na dohrao. Agar kaam nahi ho raha to "done" ke saath sach batao ke kya nahi ho saka.
        9. Agar user kisi app ka naam SPELLING bata raha ho (jaise "C L A U D E"), to wo sirf naam samjhane ke liye hai. Use kahin type mat karo. PHONE KE APPS ki list se milta julta naam dhoondo aur open_app karo. Voice se suna hua naam galat ho sakta hai (jaise "Cloud" ki jagah "Claude"), list se sab se qareeb naam chuno.
        10. "type" mein POORA text ek hi baar likho, tukron mein nahi. Beech ke steps par say_hindi sirf 3-6 alfaaz (pyare andaaz mein, jaise "जी बॉस, यूट्यूब खोल रही हूँ"); "done" aur baat cheet par 1-2 chhote jumle.
        8. Video/gaana chalane ke liye search result mein video ke TITLE wale item ko click karo, search ya mic button ko nahi.
    """.trimIndent()

    private const val GROQ_MODEL = "llama-3.3-70b-versatile"

    /** Groq (OpenAI jaisa API). Free plan mein kaafi zyada requests milti hain aur jawab tez aata hai. */
    private fun groqStep(apiKey: String, userMsg: String): JSONObject {
        val body = JSONObject()
            .put("model", GROQ_MODEL)
            .put("max_tokens", 600)
            .put("temperature", 0.3)
            .put("response_format", JSONObject().put("type", "json_object"))
            .put(
                "messages",
                JSONArray()
                    .put(JSONObject().put("role", "system").put("content", SYSTEM))
                    .put(JSONObject().put("role", "user").put("content", userMsg))
            )

        var last = ""
        for (attempt in 0 until 3) {
            val req = Request.Builder()
                .url("https://api.groq.com/openai/v1/chat/completions")
                .header("Authorization", "Bearer $apiKey")
                .post(body.toString().toRequestBody("application/json".toMediaType()))
                .build()
            try {
                client.newCall(req).execute().use { resp ->
                    val raw = resp.body?.string().orEmpty()
                    if (resp.isSuccessful) {
                        val text = JSONObject(raw).getJSONArray("choices").getJSONObject(0)
                            .getJSONObject("message").getString("content")
                        val s = text.indexOf('{')
                        val e = text.lastIndexOf('}')
                        if (s < 0 || e < s) throw RuntimeException("AI ne JSON nahi diya: $text")
                        return JSONObject(text.substring(s, e + 1))
                    }
                    last = "Groq error ${resp.code}: $raw"
                    if (resp.code == 429) throw RuntimeException("Groq ki free limit abhi khatam hai. Thori der baad try karo.\n$last")
                    if (resp.code != 500 && resp.code != 503) throw RuntimeException(last)
                }
            } catch (e: java.io.IOException) {
                last = "Internet ka masla: ${e.message}"
            }
            Thread.sleep(1500L * (attempt + 1))
        }
        throw RuntimeException(last)
    }

    private class Result(val json: JSONObject?, val code: Int, val error: String)

    fun step(apiKey: String, command: String, log: List<String>, screen: String, apps: String = ""): JSONObject {
        if (apiKey.isBlank()) throw RuntimeException("Pehle upar wale box mein API key likho.")

        val done = if (log.isEmpty()) "(abhi kuch nahi)" else log.joinToString("\n")
        val userMsg = "HUKM: $command\n\nPHONE KE APPS (open_app mein inme se sahi naam do): $apps\n\nAB TAK KE KAAM:\n$done\n\nSCREEN:\n$screen"

        // Groq key (gsk_...) ho to tez aur zyada free limit wala Groq istemal karo.
        if (apiKey.startsWith("gsk_")) return groqStep(apiKey, userMsg)

        var lastError = ""
        var sawBusy = false
        for (attempt in 0 until 2) {
            sawBusy = false
            for (model in models(apiKey)) {
                if ((cooldown[model] ?: 0L) > System.currentTimeMillis()) continue
                val r = callOnce(model, apiKey, userMsg)
                if (r.json != null) return r.json
                lastError = r.error
                val now = System.currentTimeMillis()
                when (r.code) {
                    // 429 = is model ki limit khatam: foran agla model, is ko cooldown par rakho (intezar nahi).
                    429 -> cooldown[model] = now + retrySeconds(r.error) * 1000L
                    404 -> cooldown[model] = now + 6 * 3600_000L // model band: kuch ghante chhor do
                    503 -> { cooldown[model] = now + 15_000L; sawBusy = true }
                    else -> throw RuntimeException(r.error.take(300)) // galat key wagera: foran dikhao
                }
            }
            if (!sawBusy) break
            Thread.sleep(1500) // sirf "server masroof" par ek chhoti si dobara koshish
        }
        if (sawBusy) throw RuntimeException("Google ke servers abhi masroof hain. Thori der baad dobara bolo.")
        throw QuotaException(
            "Aaj ki free limit khatam ho gayi hai. Limit kal dobara milegi, ya AI Studio mein billing on karo.\n" +
                lastError.take(160)
        )
    }

    class QuotaException(msg: String) : RuntimeException(msg)

    // ---------- Models ki list (har model ki apni alag free limit hoti hai) ----------
    private val cooldown = HashMap<String, Long>()

    @Volatile
    private var discovered: List<String>? = null

    private fun models(apiKey: String): List<String> {
        discovered?.let { return it }
        val fallback = MODELS
        val found = try { listModels(apiKey) } catch (e: Exception) { emptyList() }
        // Pehle sasti (lite) aur pakki (non-preview) models, phir baqi.
        val sorted = found.sortedWith(
            compareBy({ if (it.contains("preview") || it.contains("exp")) 1 else 0 },
                { if (it.contains("lite")) 0 else if (it.contains("flash")) 1 else 2 },
                { it })
        )
        val list = (fallback + sorted).distinct()
        discovered = list
        return list
    }

    private fun listModels(apiKey: String): List<String> {
        val req = Request.Builder()
            .url("https://generativelanguage.googleapis.com/v1beta/models?pageSize=200")
            .header("x-goog-api-key", apiKey)
            .build()
        client.newCall(req).execute().use { r ->
            if (!r.isSuccessful) return emptyList()
            val arr = JSONObject(r.body?.string().orEmpty()).optJSONArray("models") ?: return emptyList()
            val bad = Regex("image|tts|live|embedding|audio|robotics|computer|vision|learnlm|pro|omni|gemma|veo|imagen")
            val out = mutableListOf<String>()
            for (i in 0 until arr.length()) {
                val m = arr.getJSONObject(i)
                val methods = m.optJSONArray("supportedGenerationMethods")?.toString().orEmpty()
                val name = m.optString("name").removePrefix("models/")
                if (methods.contains("generateContent") && name.startsWith("gemini") &&
                    name.contains("flash") && !bad.containsMatchIn(name)
                ) out.add(name)
            }
            return out
        }
    }

    /** Google ke jawab se "kitni der baad dobara" nikalo ("retryDelay": "57534s"). */
    private fun retrySeconds(err: String): Long {
        val s = Regex("\"retryDelay\"\\s*:\\s*\"(\\d+)").find(err)?.groupValues?.get(1)?.toLongOrNull()
            ?: Regex("retry in (\\d+)(?:h|m|s)").find(err)?.groupValues?.get(1)?.toLongOrNull()
            ?: 60L
        return s.coerceIn(30L, 12 * 3600L)
    }

    private fun callOnce(model: String, apiKey: String, userMsg: String): Result {
        val gen = JSONObject()
            .put("responseMimeType", "application/json")
            .put("maxOutputTokens", 900)
            .put("temperature", 0.2)
        // 2.5 Flash mein "sochne" ka hissa band, taake jawab tez aaye.
        if (model.contains("2.5-flash")) {
            gen.put("thinkingConfig", JSONObject().put("thinkingBudget", 0))
        }

        val body = JSONObject()
            .put(
                "systemInstruction",
                JSONObject().put("parts", JSONArray().put(JSONObject().put("text", SYSTEM)))
            )
            .put(
                "contents",
                JSONArray().put(
                    JSONObject()
                        .put("role", "user")
                        .put("parts", JSONArray().put(JSONObject().put("text", userMsg)))
                )
            )
            .put("generationConfig", gen)

        val req = Request.Builder()
            .url("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
            .header("x-goog-api-key", apiKey)
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .build()

        return try {
            client.newCall(req).execute().use { resp ->
                val raw = resp.body?.string().orEmpty()
                if (!resp.isSuccessful) return Result(null, resp.code, "API error ${resp.code}: $raw")
                val text = JSONObject(raw)
                    .getJSONArray("candidates").getJSONObject(0)
                    .getJSONObject("content").getJSONArray("parts")
                    .getJSONObject(0).getString("text")
                val s = text.indexOf('{')
                val e = text.lastIndexOf('}')
                if (s < 0 || e < s) return Result(null, 0, "AI ne JSON nahi diya: $text")
                Result(JSONObject(text.substring(s, e + 1)), 200, "")
            }
        } catch (e: java.io.IOException) {
            // Internet ka masla: dobara koshish ke liye 503 jaisa treat karo.
            Result(null, 503, "Internet ka masla: ${e.message}")
        }
    }
}
