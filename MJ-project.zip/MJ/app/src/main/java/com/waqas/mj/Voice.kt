package com.waqas.mj

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Bolna (Android Urdu/Hindi awaaz) aur lagataar sunna.
 * MJ bolte waqt sunna rukta hai taake wo apni hi awaaz na sune.
 * Saare kaam main thread par.
 */
class Voice(
    private val ctx: Context,
    private val onHeard: (String) -> Unit,
    private val onInfo: (String) -> Unit
) {
    private val main = Handler(Looper.getMainLooper())
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private val pending = ConcurrentHashMap<String, () -> Unit>()
    private var recognizer: SpeechRecognizer? = null
    private var continuous = false
    private var speaking = 0
    private val startRunnable = Runnable { startListening() }

    init {
        tts = TextToSpeech(ctx) { status ->
            if (status == TextToSpeech.SUCCESS) {
                fun ok(r: Int?) = r != null && r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED
                ttsReady = ok(tts?.setLanguage(Locale("ur", "PK"))) || ok(tts?.setLanguage(Locale("hi", "IN")))
                tts?.setSpeechRate(1.1f)
                tts?.setPitch(1.15f)
                if (!ttsReady) onInfo("Urdu/Hindi awaaz nahi mili. Settings > Text-to-speech se Hindi download karo.")
            }
        }
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onDone(id: String?) { finish(id) }
            @Deprecated("Deprecated in Java")
            override fun onError(id: String?) { finish(id) }
            override fun onStop(id: String?, interrupted: Boolean) { finish(id) }
        })
    }

    private fun finish(id: String?) {
        if (id == null) return
        pending.remove(id)?.let { cb -> main.post { cb() } }
    }

    /** Bolo. flush = true: jo bol rahi hai use rok kar ye bolo. onDone: bolna khatam hone par. */
    fun say(text: String, flush: Boolean = false, onDone: () -> Unit = {}) {
        if (!ttsReady || text.isBlank()) { onDone(); return }
        val id = System.nanoTime().toString()
        val done = AtomicBoolean(false)
        speaking++
        try { recognizer?.cancel() } catch (e: Exception) {}

        val end: () -> Unit = {
            if (done.compareAndSet(false, true)) {
                speaking = maxOf(0, speaking - 1)
                if (speaking == 0) restartSoon(300)
                onDone()
            }
        }
        pending[id] = end
        // Safai: kisi wajah se bolna khatam ka signal na aaye to 15 second baad aage barho.
        main.postDelayed({ pending.remove(id); end() }, 15_000)
        if (flush) try { tts?.stop() } catch (e: Exception) {}
        tts?.speak(text, if (flush) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD, null, id)
    }

    // ---------- Lagataar sunna ----------
    fun startContinuous() {
        if (continuous) return
        continuous = true
        restartSoon(0)
    }

    fun stopContinuous() {
        continuous = false
        main.removeCallbacks(startRunnable)
        try { recognizer?.destroy() } catch (e: Exception) {}
        recognizer = null
    }

    private fun restartSoon(delayMs: Long) {
        main.removeCallbacks(startRunnable)
        main.postDelayed(startRunnable, delayMs)
    }

    private fun startListening() {
        if (!continuous || speaking > 0) return
        if (!SpeechRecognizer.isRecognitionAvailable(ctx)) {
            onInfo("Is phone par speech recognition maujood nahi.")
            return
        }
        try { recognizer?.destroy() } catch (e: Exception) {}
        val r = SpeechRecognizer.createSpeechRecognizer(ctx)
        r.setRecognitionListener(object : RecognitionListener {
            override fun onResults(results: Bundle?) {
                val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (!text.isNullOrBlank()) onHeard(text)
                restartSoon(250)
            }

            override fun onError(error: Int) {
                if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
                    continuous = false
                    onInfo("Mic ki ijazat nahi. App ki settings mein Microphone allow karo.")
                    return
                }
                // Kuch na bolne ya samajh na aane par foran dobara sunna.
                val quick = error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT || error == SpeechRecognizer.ERROR_NO_MATCH
                restartSoon(if (quick) 150 else 1500)
            }

            override fun onReadyForSpeech(p: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rms: Float) {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(p: Bundle?) {}
            override fun onEvent(t: Int, p: Bundle?) {}
        })
        recognizer = r

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ur-PK")
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, ctx.packageName)
            putExtra("android.speech.extra.SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS", 1500L)
            putExtra("android.speech.extra.SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS", 1200L)
        }
        r.startListening(intent)
    }

    fun shutdown() {
        stopContinuous()
        main.removeCallbacksAndMessages(null)
        try { tts?.shutdown() } catch (e: Exception) {}
    }
}
