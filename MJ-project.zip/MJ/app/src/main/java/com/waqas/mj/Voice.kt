package com.waqas.mj

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap

/**
 * Sunna (lagataar, background mein) aur bolna (text-to-speech).
 * Recognizer ke saare kaam main thread par hone chahiye. MJ bolte waqt sunna rukta hai
 * taake wo apni hi awaaz na sun le.
 */
class Voice(
    private val ctx: Context,
    private val onHeard: (String) -> Unit,
    private val onInfo: (String) -> Unit
) {
    private val main = Handler(Looper.getMainLooper())
    private val prefs = ctx.getSharedPreferences("mj", Context.MODE_PRIVATE)
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private val callbacks = ConcurrentHashMap<String, () -> Unit>()
    private var recognizer: SpeechRecognizer? = null
    private var continuous = false
    private var speaking = 0
    private val startRunnable = Runnable { startListening() }

    init {
        tts = TextToSpeech(ctx) { status ->
            if (status == TextToSpeech.SUCCESS) {
                // Pehle Urdu, na mile to Hindi awaaz (bolchaal mein lagbhag ek hi hai).
                fun ok(r: Int?) = r != null && r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED
                ttsReady = ok(tts?.setLanguage(Locale("ur", "PK"))) || ok(tts?.setLanguage(Locale("hi", "IN")))
                if (!ttsReady) onInfo("Hindi/Urdu awaaz install nahi. Settings > Text-to-speech > Google > Hindi awaaz download karo.")
                applySavedVoice()
                tts?.setSpeechRate(1.3f)
                tts?.setPitch(1.15f)
            }
        }
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onDone(id: String?) { id?.let { callbacks.remove(it)?.invoke() } }
            @Deprecated("Deprecated in Java")
            override fun onError(id: String?) { id?.let { callbacks.remove(it)?.invoke() } }
            override fun onStop(id: String?, interrupted: Boolean) { id?.let { callbacks.remove(it)?.invoke() } }
        })
    }

    // ---------- Awaaz chunna ----------
    private fun hindiVoices() = try {
        tts?.voices?.filter { it.locale.language == "hi" || it.locale.language == "ur" }
            ?.sortedBy { it.name } ?: emptyList()
    } catch (e: Exception) {
        emptyList()
    }

    private fun applySavedVoice() {
        val saved = prefs.getString("voice", null) ?: return
        hindiVoices().firstOrNull { it.name == saved }?.let { tts?.setVoice(it) }
    }

    /** Agli awaaz chunta hai aur ek namoona bolta hai. Female wali mile to ruk jao. */
    fun nextVoice() {
        val vs = hindiVoices()
        if (vs.isEmpty()) { onInfo("Koi Hindi/Urdu awaaz nahi mili. Settings > Text-to-speech > Google se download karo."); return }
        val i = vs.indexOfFirst { it.name == tts?.voice?.name }
        val v = vs[(i + 1) % vs.size]
        tts?.stop()
        tts?.setVoice(v)
        prefs.edit().putString("voice", v.name).apply()
        onInfo("Awaaz ${(i + 1) % vs.size + 1}/${vs.size}")
        speak("जी, मैं एमजे हूँ। यह मेरी आवाज़ है।")
    }

    // ---------- Bolna ----------
    fun speak(urdu: String, onDone: () -> Unit = {}) {
        if (!ttsReady || urdu.isBlank()) { onDone(); return }
        val id = System.nanoTime().toString()
        speaking++
        try { recognizer?.cancel() } catch (e: Exception) {}
        callbacks[id] = {
            main.post {
                speaking = maxOf(0, speaking - 1)
                if (speaking == 0) restartSoon(300)
            }
            onDone()
        }
        // Safai: agar kisi wajah se TTS ka jawab na aaye to 25 second baad sunna dobara shuru.
        main.postDelayed({ callbacks.remove(id)?.invoke() }, 25_000)
        tts?.speak(urdu, TextToSpeech.QUEUE_ADD, null, id)
    }

    // ---------- Lagataar sunna ----------
    fun startContinuous() {
        continuous = true
        restartSoon(0)
    }

    fun stopContinuous() {
        continuous = false
        main.removeCallbacks(startRunnable)
        try { recognizer?.destroy() } catch (e: Exception) {}
        recognizer = null
    }

    private fun restartSoon(delayMs: Long) {
        main.removeCallbacks(startRunnable)
        main.postDelayed(startRunnable, delayMs)
    }

    private fun startListening() {
        if (!continuous || speaking > 0) return
        if (!SpeechRecognizer.isRecognitionAvailable(ctx)) {
            onInfo("Is phone par speech recognition maujood nahi.")
            return
        }
        try { recognizer?.destroy() } catch (e: Exception) {}
        val r = SpeechRecognizer.createSpeechRecognizer(ctx)
        r.setRecognitionListener(object : RecognitionListener {
            override fun onResults(results: Bundle?) {
                val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (!text.isNullOrBlank()) onHeard(text)
                restartSoon(250)
            }

            override fun onError(error: Int) {
                if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
                    continuous = false
                    onInfo("Mic ki ijazat nahi mili. App ki settings mein Microphone allow karo.")
                    return
                }
                // 6 = kuch bola nahi, 7 = samajh nahi aaya: ye normal hain, foran dobara sunna.
                val quick = error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT || error == SpeechRecognizer.ERROR_NO_MATCH
                restartSoon(if (quick) 150 else 1500)
            }

            override fun onReadyForSpeech(p: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rms: Float) {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(p: Bundle?) {}
            override fun onEvent(t: Int, p: Bundle?) {}
        })
        recognizer = r

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ur-PK")
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, ctx.packageName)
            // Bolne ke beech thori khamoshi par foran na rukna (sab phones par kaam nahi karta).
            putExtra("android.speech.extra.SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS", 2000L)
            putExtra("android.speech.extra.SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS", 1500L)
        }
        r.startListening(intent)
    }

    fun shutdown() {
        stopContinuous()
        main.removeCallbacksAndMessages(null)
        tts?.shutdown()
    }
}
