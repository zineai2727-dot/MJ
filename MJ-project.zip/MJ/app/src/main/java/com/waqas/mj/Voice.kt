package com.waqas.mj

import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap

/**
 * Bolna aur sunna.
 * Bolna: ek ek kar ke (queue). Jo awaaz 4 second mein shuru na ho use chhod kar aage badhta hai,
 * taake mic kabhi bekaar band na rahe. TTS do dafa fail ho to engine dobara shuru hota hai.
 * Sunna: ek hi recognizer. MJ bol rahi ho to mic band. Bolne ke baad thora ruk kar dobara sunna.
 * Har masla log mein dikhta hai.
 */
class Voice(
    private val ctx: Context,
    private val onHeard: (String) -> Unit,
    private val onInfo: (String) -> Unit,
    private val onPartial: (String) -> Unit = {}
) {
    private class Item(val text: String, val onDone: () -> Unit) {
        var id: String = ""
    }

    private val main = Handler(Looper.getMainLooper())

    // ---------- TTS ----------
    private var tts: TextToSpeech? = null
    @Volatile private var ttsReady = false
    @Volatile private var ttsInitDone = false
    private val items = ArrayDeque<Item>()      // sirf main thread
    private var current: Item? = null           // sirf main thread
    private val byId = ConcurrentHashMap<String, Item>()
    private val started = ConcurrentHashMap.newKeySet<String>()
    private var failStreak = 0

    private val ttsListener = object : UtteranceProgressListener() {
        override fun onStart(id: String?) {
            if (id == null) return
            started.add(id)
            main.post { failStreak = 0 }
        }
        override fun onDone(id: String?) { finish(id) }
        @Deprecated("Deprecated in Java")
        override fun onError(id: String?) { finish(id) }
        override fun onError(id: String?, errorCode: Int) { finish(id) }
        override fun onStop(id: String?, interrupted: Boolean) { finish(id) }
    }

    // ---------- Sunna ----------
    private var recognizer: SpeechRecognizer? = null
    private var continuous = false
    private var listeningNow = false
    private var lastStartAt = 0L
    private var lang = "ur-PK"
    private var lastErrorLogged = -1
    private val startRunnable = Runnable { startListening() }

    private val watchdog = object : Runnable {
        override fun run() {
            if (continuous && !isSpeaking()) {
                val stuck = listeningNow && System.currentTimeMillis() - lastStartAt > 15_000
                if (!listeningNow || stuck) startListening()
            }
            main.postDelayed(this, 3_000)
        }
    }

    private val listener = object : RecognitionListener {
        override fun onResults(results: Bundle?) {
            listeningNow = false
            lastErrorLogged = -1
            val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
            val conf = results?.getFloatArray(SpeechRecognizer.CONFIDENCE_SCORES)?.firstOrNull() ?: -1f
            if (!text.isNullOrBlank()) {
                // Conf 0 ya kam "pata nahi" hota hai, usay rad nahi karte.
                if (conf > 0f && conf < 0.25f) onInfo("Sunai diya lekin saaf nahi tha, chhod diya: $text")
                else onHeard(text)
            }
            restartSoon(200)
        }

        override fun onPartialResults(p: Bundle?) {
            val t = p?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
            if (!t.isNullOrBlank()) onPartial(t)
        }

        override fun onError(error: Int) {
            listeningNow = false
            if (error != lastErrorLogged && error != SpeechRecognizer.ERROR_NO_MATCH && error != SpeechRecognizer.ERROR_SPEECH_TIMEOUT) {
                onInfo("Mic masla: ${errorName(error)} (code $error)")
            }
            lastErrorLogged = error
            if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
                continuous = false
                onInfo("Mic ki ijazat nahi. App ki settings mein Microphone allow karo.")
                return
            }
            // ERROR_CLIENT ke baad recognizer kharab ho jata hai: naya banao.
            if (error == SpeechRecognizer.ERROR_CLIENT || error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) destroyRecognizer()
            // Urdu sunne ki suvidha na ho to Hindi.
            if ((error == 12 || error == 13) && lang != "hi-IN") {
                lang = "hi-IN"
                onInfo("Urdu sunne ki suvidha nahi. Ab Hindi mein sun rahi hoon.")
            }
            val wait = when (error) {
                SpeechRecognizer.ERROR_SPEECH_TIMEOUT, SpeechRecognizer.ERROR_NO_MATCH -> 150L
                SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> 1500L
                SpeechRecognizer.ERROR_CLIENT -> 1200L
                else -> 1000L
            }
            restartSoon(wait)
        }

        override fun onReadyForSpeech(p: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rms: Float) {}
        override fun onBufferReceived(b: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onEvent(t: Int, p: Bundle?) {}
    }

    init {
        initTts()
    }

    private fun initTts() {
        ttsInitDone = false
        ttsReady = false
        val engine = TextToSpeech(ctx) { status -> main.post { onTtsInit(status) } }
        engine.setOnUtteranceProgressListener(ttsListener)
        tts = engine
    }

    private fun reinitTts() {
        onInfo("Awaaz ka engine dobara shuru kar rahi hoon.")
        try { tts?.shutdown() } catch (e: Exception) {}
        tts = null
        initTts()
    }

    private fun onTtsInit(status: Int) {
        ttsInitDone = true
        if (status != TextToSpeech.SUCCESS) {
            onInfo("Text-to-speech shuru nahi hua. Google Text-to-speech app on karo.")
            return
        }
        val t = tts ?: return
        fun ok(r: Int?) = r != null && r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED
        ttsReady = ok(t.setLanguage(Locale("ur", "PK"))) || ok(t.setLanguage(Locale("hi", "IN")))
        t.setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ASSISTANT)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build()
        )
        t.setSpeechRate(1.1f)
        t.setPitch(1.15f)
        if (!ttsReady) onInfo("Urdu/Hindi awaaz nahi mili. Google Text-to-speech mein Hindi voice install karo.")
    }

    private fun isSpeaking(): Boolean = current != null || items.isNotEmpty()

    private fun finish(id: String?) {
        if (id == null) return
        val item = byId[id] ?: return
        main.post { complete(item) }
    }

    /** Bolo. flush = true: jo bol rahi hai use rok kar ye bolo. onDone: is line ke khatam hone par. */
    fun say(text: String, flush: Boolean = false, onDone: () -> Unit = {}) {
        if (text.isBlank()) { onDone(); return }
        if (flush) {
            items.clear()
            try { tts?.stop() } catch (e: Exception) {}
        }
        items.addLast(Item(text, onDone))
        pump()
    }

    /** Agli line bolo. Queue khali ho to mic dobara shuru. Sirf main thread par. */
    private fun pump() {
        if (current != null) return
        val item = items.firstOrNull()
        if (item == null) {
            restartSoon(700) // bolne ke baad thori khamoshi, phir sunna
            return
        }
        if (!ttsReady) {
            if (!ttsInitDone) {
                main.postDelayed({ pump() }, 300)
                return
            }
            items.removeFirst()
            onInfo("Awaaz taiyaar nahi. Google Text-to-speech mein Hindi voice install karo.")
            item.onDone()
            pump()
            return
        }
        items.removeFirst()
        current = item
        // Bolne se pehle mic poori tarah band: adhoora recognizer "client" / "busy" errors deta hai.
        destroyRecognizer()
        listeningNow = false
        val id = System.nanoTime().toString()
        item.id = id
        byId[id] = item

        // Safety: khatam ka signal na aaye to 30 second baad aage barho.
        main.postDelayed({
            if (current === item) {
                onInfo("Awaaz atak gayi, aage badh rahi hoon.")
                complete(item)
            }
        }, 30_000)
        // Agar 4 second mein awaaz shuru na ho to ye line chhod do aur engine kharab samjho.
        main.postDelayed({
            if (current === item && !started.contains(id)) {
                onInfo("Awaaz shuru nahi hui. Google Text-to-speech ki settings check karo.")
                failStreak++
                if (failStreak >= 2) {
                    failStreak = 0
                    reinitTts()
                }
                complete(item)
            }
        }, 4_000)
        main.postDelayed({
            val r = tts?.speak(item.text, TextToSpeech.QUEUE_ADD, null, id)
            if (r == TextToSpeech.ERROR) {
                onInfo("Awaaz chalane mein masla hua.")
                complete(item)
            }
        }, 250)
    }

    private fun complete(item: Item) {
        if (current !== item) return
        current = null
        byId.remove(item.id)
        started.remove(item.id)
        item.onDone()
        pump()
    }

    // ---------- Lagataar sunna ----------
    fun startContinuous() {
        if (continuous) return
        continuous = true
        restartSoon(0)
        main.postDelayed(watchdog, 3_000)
    }

    fun stopContinuous() {
        continuous = false
        main.removeCallbacks(startRunnable)
        main.removeCallbacks(watchdog)
        listeningNow = false
        destroyRecognizer()
    }

    private fun destroyRecognizer() {
        try { recognizer?.cancel() } catch (e: Exception) {}
        try { recognizer?.destroy() } catch (e: Exception) {}
        recognizer = null
    }

    private fun restartSoon(delayMs: Long) {
        main.removeCallbacks(startRunnable)
        main.postDelayed(startRunnable, delayMs)
    }

    private fun errorName(e: Int) = when (e) {
        SpeechRecognizer.ERROR_AUDIO -> "audio"
        SpeechRecognizer.ERROR_CLIENT -> "client"
        SpeechRecognizer.ERROR_NETWORK -> "internet"
        SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "internet timeout"
        SpeechRecognizer.ERROR_NO_MATCH -> "kuch samajh nahi aaya"
        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "recognizer busy"
        SpeechRecognizer.ERROR_SERVER -> "server"
        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "ijazat nahi"
        12, 13 -> "zaban support nahi"
        else -> "unknown"
    }

    private fun startListening() {
        if (!continuous || isSpeaking()) return
        if (!SpeechRecognizer.isRecognitionAvailable(ctx)) {
            onInfo("Is phone par speech recognition maujood nahi.")
            return
        }
        val r = recognizer ?: SpeechRecognizer.createSpeechRecognizer(ctx).also {
            it.setRecognitionListener(listener)
            recognizer = it
        }
        listeningNow = true
        lastStartAt = System.currentTimeMillis()

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, ctx.packageName)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            // Ruk ruk kar bolne par bhi poori baat sune.
            putExtra("android.speech.extra.SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS", 2000L)
            putExtra("android.speech.extra.SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS", 1500L)
        }
        try {
            r.startListening(intent)
        } catch (e: Exception) {
            listeningNow = false
            onInfo("Mic shuru nahi ho saka: ${e.message}")
            destroyRecognizer()
            restartSoon(2000)
        }
    }

    fun shutdown() {
        stopContinuous()
        main.removeCallbacksAndMessages(null)
        try { tts?.shutdown() } catch (e: Exception) {}
    }
}
