package com.waqas.mj

import android.content.Context
import android.media.AudioAttributes
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap

/**
 * MJ ki awaaz (TTS).
 * - Ek ek line bolti hai. flush = true par purani queue foran khatam (awaaz kaam ke saath chale, peeche na rahe).
 * - Behtar Hindi/Urdu female awaaz chunti hai (agar phone par ho).
 * - 8 second mein awaaz shuru na ho to line chhod kar aage badhti hai; engine do dafa fail ho to dobara shuru.
 * onSpeaking(true/false): Ears ko batata hai ke mic ka sunna rok do ya chalu karo.
 */
class Voice(
    private val ctx: Context,
    private val onInfo: (String) -> Unit,
    private val onSpeaking: (Boolean) -> Unit
) {
    private class Item(val text: String, val onDone: () -> Unit) {
        var id: String = ""
    }

    private val main = Handler(Looper.getMainLooper())
    private var tts: TextToSpeech? = null
    @Volatile private var ttsReady = false
    @Volatile private var ttsInitDone = false
    private val items = ArrayDeque<Item>()      // sirf main thread
    private var current: Item? = null           // sirf main thread
    private val byId = ConcurrentHashMap<String, Item>()
    private val started = ConcurrentHashMap.newKeySet<String>()
    private var failStreak = 0

    private val ttsListener = object : UtteranceProgressListener() {
        override fun onStart(id: String?) {
            if (id == null) return
            started.add(id)
            main.post { failStreak = 0 }
        }
        override fun onDone(id: String?) { finish(id) }
        @Deprecated("Deprecated in Java")
        override fun onError(id: String?) { finish(id) }
        override fun onError(id: String?, errorCode: Int) { finish(id) }
        override fun onStop(id: String?, interrupted: Boolean) { finish(id) }
    }

    init {
        initTts()
    }

    private fun initTts() {
        ttsInitDone = false
        ttsReady = false
        val engine = TextToSpeech(ctx) { status -> main.post { onTtsInit(status) } }
        engine.setOnUtteranceProgressListener(ttsListener)
        tts = engine
    }

    private fun reinitTts() {
        onInfo("Awaaz ka engine dobara shuru kar rahi hoon.")
        try { tts?.shutdown() } catch (e: Exception) {}
        tts = null
        initTts()
    }

    private fun onTtsInit(status: Int) {
        ttsInitDone = true
        if (status != TextToSpeech.SUCCESS) {
            onInfo("Text-to-speech shuru nahi hua. Google Text-to-speech app on karo.")
            return
        }
        val t = tts ?: return
        fun ok(r: Int?) = r != null && r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED
        ttsReady = ok(t.setLanguage(Locale("hi", "IN"))) || ok(t.setLanguage(Locale("ur", "PK")))
        t.setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ASSISTANT)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build()
        )
        pickFemaleVoice(t)
        t.setSpeechRate(1.0f)
        t.setPitch(1.1f)
        if (!ttsReady) onInfo("Hindi awaaz nahi mili. Google Text-to-speech mein Hindi voice install karo.")
    }

    /** Hindi/Urdu awaazon mein se behtar female awaaz chunna. Naam mein "hia" ya "female" ho to pehle. */
    private fun pickFemaleVoice(t: TextToSpeech) {
        val voices = try { t.voices } catch (e: Exception) { null } ?: return
        val best = voices
            .filter { it.locale.language == "hi" || it.locale.language == "ur" }
            .maxByOrNull { v ->
                val n = v.name.lowercase()
                var s = 0
                if (n.contains("hia") || n.contains("female")) s += 10
                if (n.contains("hid") || n.contains("male")) s -= 10
                if (v.isNetworkConnectionRequired) s += 3
                s
            } ?: return
        t.voice = best
        onInfo("Awaaz chuni gayi: ${best.name}")
    }

    private fun finish(id: String?) {
        if (id == null) return
        val item = byId[id] ?: return
        main.post { complete(item) }
    }

    /** Bolo. flush = true: purani queue foran khatam, ye line abhi bolo. onDone: is line ke khatam hone par. */
    fun say(text: String, flush: Boolean = false, onDone: () -> Unit = {}) {
        if (text.isBlank()) { onDone(); return }
        if (flush) {
            val dropped = items.toList()
            items.clear()
            // Jo lines chhod deeN, unke onDone bhi chalane hain taake koi intezar mein na ruk jaye.
            dropped.forEach { it.onDone() }
            try { tts?.stop() } catch (e: Exception) {}
        }
        items.addLast(Item(text, onDone))
        pump()
    }

    /** Agli line bolo. Queue khali ho to sunna dobara chalu. Sirf main thread par. */
    private fun pump() {
        if (current != null) return
        val item = items.firstOrNull()
        if (item == null) {
            onSpeaking(false)
            return
        }
        if (!ttsReady) {
            if (!ttsInitDone) {
                main.postDelayed({ pump() }, 300)
                return
            }
            items.removeFirst()
            onInfo("Awaaz taiyaar nahi. Google Text-to-speech mein Hindi voice install karo.")
            item.onDone()
            pump()
            return
        }
        items.removeFirst()
        current = item
        onSpeaking(true)
        val id = System.nanoTime().toString()
        item.id = id
        byId[id] = item

        // Safety: khatam ka signal na aaye to 30 second baad aage barho.
        main.postDelayed({
            if (current === item) {
                onInfo("Awaaz atak gayi, aage badh rahi hoon.")
                complete(item)
            }
        }, 30_000)
        // Agar 8 second mein awaaz shuru na ho to line chhod do.
        main.postDelayed({
            if (current === item && !started.contains(id)) {
                onInfo("Awaaz shuru nahi hui. Google Text-to-speech ki settings check karo.")
                failStreak++
                if (failStreak >= 2) {
                    failStreak = 0
                    reinitTts()
                }
                complete(item)
            }
        }, 8_000)
        main.postDelayed({
            val r = tts?.speak(item.text, TextToSpeech.QUEUE_ADD, null, id)
            if (r == TextToSpeech.ERROR) {
                onInfo("Awaaz chalane mein masla hua.")
                complete(item)
            }
        }, 50)
    }

    private fun complete(item: Item) {
        if (current !== item) return
        current = null
        byId.remove(item.id)
        started.remove(item.id)
        item.onDone()
        pump()
    }

    fun shutdown() {
        main.removeCallbacksAndMessages(null)
        try { tts?.shutdown() } catch (e: Exception) {}
    }
}
