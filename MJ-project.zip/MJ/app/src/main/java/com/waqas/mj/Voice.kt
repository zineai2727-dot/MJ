package com.waqas.mj

import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Bolna (Urdu/Hindi awaaz) aur sunna.
 * - MJ bol rahi ho to mic band. Bolne ke baad thora ruk kar dobara sunna (apni awaaz na sune).
 * - Ek hi recognizer dobara use hota hai (har baar naya banane se mic atakta tha).
 * - Urdu sunne ki suvidha na ho to Hindi par chala jata hai.
 * - Har masla / chhoda gaya nateeja log mein dikhta hai.
 */
class Voice(
    private val ctx: Context,
    private val onHeard: (String) -> Unit,
    private val onInfo: (String) -> Unit,
    private val onPartial: (String) -> Unit = {}
) {
    private val main = Handler(Looper.getMainLooper())
    private var tts: TextToSpeech? = null
    @Volatile private var ttsReady = false
    private val pending = ConcurrentHashMap<String, () -> Unit>()
    private val started = ConcurrentHashMap.newKeySet<String>()
    private var recognizer: SpeechRecognizer? = null
    private var continuous = false
    private var speaking = 0
    private var listeningNow = false
    private var lastStartAt = 0L
    private var lang = "ur-PK"
    private var lastErrorLogged = -1
    private val startRunnable = Runnable { startListening() }

    private val watchdog = object : Runnable {
        override fun run() {
            if (continuous && speaking == 0) {
                val stuck = listeningNow && System.currentTimeMillis() - lastStartAt > 15_000
                if (!listeningNow || stuck) startListening()
            }
            main.postDelayed(this, 3_000)
        }
    }

    private val listener = object : RecognitionListener {
        override fun onResults(results: Bundle?) {
            listeningNow = false
            lastErrorLogged = -1
            val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
            val conf = results?.getFloatArray(SpeechRecognizer.CONFIDENCE_SCORES)?.firstOrNull() ?: -1f
            if (!text.isNullOrBlank()) {
                // Conf 0 ya kam "pata nahi" hota hai, to usay rad nahi karte.
                if (conf > 0f && conf < 0.25f) onInfo("Sunai diya lekin saaf nahi tha, chhod diya: $text")
                else onHeard(text)
            }
            restartSoon(200)
        }

        override fun onPartialResults(p: Bundle?) {
            val t = p?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
            if (!t.isNullOrBlank()) onPartial(t)
        }

        override fun onError(error: Int) {
            listeningNow = false
            if (error != lastErrorLogged && error != SpeechRecognizer.ERROR_NO_MATCH && error != SpeechRecognizer.ERROR_SPEECH_TIMEOUT) {
                onInfo("Mic masla: ${errorName(error)} (code $error)")
            }
            lastErrorLogged = error
            if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
                continuous = false
                onInfo("Mic ki ijazat nahi. App ki settings mein Microphone allow karo.")
                return
            }
            // Urdu sunne ki suvidha na ho to Hindi.
            if ((error == 12 || error == 13) && lang != "hi-IN") {
                lang = "hi-IN"
                onInfo("Urdu sunne ki suvidha nahi. Ab Hindi mein sun rahi hoon.")
            }
            val wait = when (error) {
                SpeechRecognizer.ERROR_SPEECH_TIMEOUT, SpeechRecognizer.ERROR_NO_MATCH -> 150L
                SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> 1500L
                else -> 1000L
            }
            restartSoon(wait)
        }

        override fun onReadyForSpeech(p: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rms: Float) {}
        override fun onBufferReceived(b: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onEvent(t: Int, p: Bundle?) {}
    }

    init {
        tts = TextToSpeech(ctx) { status ->
            if (status == TextToSpeech.SUCCESS) {
                fun ok(r: Int?) = r != null && r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED
                ttsReady = ok(tts?.setLanguage(Locale("ur", "PK"))) || ok(tts?.setLanguage(Locale("hi", "IN")))
                tts?.setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ASSISTANT)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
                tts?.setSpeechRate(1.1f)
                tts?.setPitch(1.15f)
                if (!ttsReady) onInfo("Urdu/Hindi awaaz nahi mili. Google Text-to-speech mein Hindi voice install karo.")
            } else {
                onInfo("Text-to-speech shuru nahi hua. Google Text-to-speech app on karo.")
            }
        }
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) { if (id != null) started.add(id) }
            override fun onDone(id: String?) { finish(id) }
            @Deprecated("Deprecated in Java")
            override fun onError(id: String?) { finish(id) }
            override fun onError(id: String?, errorCode: Int) { finish(id) }
            override fun onStop(id: String?, interrupted: Boolean) { finish(id) }
        })
    }

    private fun errorName(e: Int) = when (e) {
        SpeechRecognizer.ERROR_AUDIO -> "audio"
        SpeechRecognizer.ERROR_CLIENT -> "client"
        SpeechRecognizer.ERROR_NETWORK -> "internet"
        SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "internet timeout"
        SpeechRecognizer.ERROR_NO_MATCH -> "kuch samajh nahi aaya"
        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "recognizer busy"
        SpeechRecognizer.ERROR_SERVER -> "server"
        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "ijazat nahi"
        12, 13 -> "zaban support nahi"
        else -> "unknown"
    }

    private fun finish(id: String?) {
        if (id == null) return
        started.remove(id)
        pending.remove(id)?.let { cb -> main.post { cb() } }
    }

    /** Bolo. flush = true: jo bol rahi hai use rok kar ye bolo. onDone: bolna khatam hone par. */
    fun say(text: String, flush: Boolean = false, onDone: () -> Unit = {}) {
        if (text.isBlank()) { onDone(); return }
        if (!ttsReady) {
            onInfo("Awaaz taiyaar nahi. Google Text-to-speech mein Hindi voice install karo.")
            onDone()
            return
        }
        val id = System.nanoTime().toString()
        val done = AtomicBoolean(false)
        speaking++
        listeningNow = false
        cancelRecognizer()

        val end: () -> Unit = {
            if (done.compareAndSet(false, true)) {
                speaking = maxOf(0, speaking - 1)
                // Bolne ke baad thori khamoshi: apni awaaz ki goonj na sune.
                if (speaking == 0) restartSoon(700)
                onDone()
            }
        }
        pending[id] = end
        // Safety: khatam ka signal na aaye to 30 second baad aage barho.
        main.postDelayed({ pending.remove(id)?.invoke() }, 30_000)
        // Sirf log: 4 second mein bhi awaaz shuru na ho to pata chale.
        main.postDelayed({
            if (pending.containsKey(id) && !started.contains(id)) {
                onInfo("Awaaz abhi shuru nahi hui. Google Text-to-speech ki settings check karo.")
            }
        }, 4_000)
        main.postDelayed({
            if (flush) try { tts?.stop() } catch (e: Exception) {}
            val r = tts?.speak(text, if (flush) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD, null, id)
            if (r == TextToSpeech.ERROR) {
                onInfo("Awaaz chalane mein masla hua.")
                pending.remove(id)?.invoke()
            }
        }, 250)
    }

    // ---------- Lagataar sunna ----------
    fun startContinuous() {
        if (continuous) return
        continuous = true
        restartSoon(0)
        main.postDelayed(watchdog, 3_000)
    }

    fun stopContinuous() {
        continuous = false
        main.removeCallbacks(startRunnable)
        main.removeCallbacks(watchdog)
        listeningNow = false
        destroyRecognizer()
    }

    private fun cancelRecognizer() {
        try { recognizer?.cancel() } catch (e: Exception) {}
    }

    private fun destroyRecognizer() {
        try { recognizer?.cancel() } catch (e: Exception) {}
        try { recognizer?.destroy() } catch (e: Exception) {}
        recognizer = null
    }

    private fun restartSoon(delayMs: Long) {
        main.removeCallbacks(startRunnable)
        main.postDelayed(startRunnable, delayMs)
    }

    private fun startListening() {
        if (!continuous || speaking > 0) return
        if (!SpeechRecognizer.isRecognitionAvailable(ctx)) {
            onInfo("Is phone par speech recognition maujood nahi.")
            return
        }
        val r = recognizer ?: SpeechRecognizer.createSpeechRecognizer(ctx).also {
            it.setRecognitionListener(listener)
            recognizer = it
        }
        listeningNow = true
        lastStartAt = System.currentTimeMillis()

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, ctx.packageName)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            // Ruk ruk kar bolne par bhi poori baat sune.
            putExtra("android.speech.extra.SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS", 2000L)
            putExtra("android.speech.extra.SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS", 1500L)
        }
        try {
            r.startListening(intent)
        } catch (e: Exception) {
            listeningNow = false
            onInfo("Mic shuru nahi ho saka: ${e.message}")
            destroyRecognizer()
            restartSoon(2000)
        }
    }

    fun shutdown() {
        stopContinuous()
        main.removeCallbacksAndMessages(null)
        try { tts?.shutdown() } catch (e: Exception) {}
    }
}
