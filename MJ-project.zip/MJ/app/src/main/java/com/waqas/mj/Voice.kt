package com.waqas.mj

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

/** Sunna (speech-to-text) aur bolna (text-to-speech, Urdu). Sab main thread se istemal karo. */
class Voice(
    private val ctx: Context,
    private val onHeard: (String) -> Unit,
    private val onInfo: (String) -> Unit
) {
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private val callbacks = mutableMapOf<String, () -> Unit>()
    private var recognizer: SpeechRecognizer? = null

    init {
        tts = TextToSpeech(ctx) { status ->
            if (status == TextToSpeech.SUCCESS) {
                // Pehle Urdu, na mile to Hindi awaaz (bolchaal mein lagbhag ek hi hai).
                fun ok(r: Int?) = r != null && r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED
                ttsReady = ok(tts?.setLanguage(Locale("ur", "PK"))) || ok(tts?.setLanguage(Locale("hi", "IN")))
                if (!ttsReady) onInfo("Hindi/Urdu awaaz install nahi. Settings > Text-to-speech > Google > Hindi awaaz download karo.")
                // Female awaaz: agar device par ek se zyada Urdu voices hon to yahan chun sakte ho.
                tts?.setPitch(1.1f)
            }
        }
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onDone(id: String?) { callbacks.remove(id)?.invoke() }
            @Deprecated("Deprecated in Java")
            override fun onError(id: String?) { callbacks.remove(id)?.invoke() }
        })
    }

    fun speak(urdu: String, onDone: () -> Unit = {}) {
        if (!ttsReady || urdu.isBlank()) { onDone(); return }
        val id = System.nanoTime().toString()
        callbacks[id] = onDone
        tts?.speak(urdu, TextToSpeech.QUEUE_ADD, null, id)
    }

    fun listen() {
        if (!SpeechRecognizer.isRecognitionAvailable(ctx)) {
            onInfo("Is phone par speech recognition maujood nahi.")
            return
        }
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(ctx).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onResults(results: Bundle?) {
                    val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    if (!text.isNullOrBlank()) onHeard(text)
                }
                override fun onError(error: Int) { onInfo("Sunai nahi diya (code $error). Dobara bolo.") }
                override fun onReadyForSpeech(p: Bundle?) { onInfo("Sun rahi hoon...") }
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rms: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(p: Bundle?) {}
                override fun onEvent(t: Int, p: Bundle?) {}
            })
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ur-PK")
        }
        recognizer?.startListening(intent)
    }

    fun shutdown() {
        recognizer?.destroy()
        tts?.shutdown()
    }
}
