package com.waqas.mj

import android.content.Context
import android.media.AudioAttributes
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap

/**
 * MJ ki awaaz (TTS). Ek ek line queue mein bolti hai.
 * Jo line 4 second mein shuru na ho use chhod kar aage badhti hai. Engine do dafa fail ho to dobara shuru.
 * onSpeaking(true/false): Ears ko batata hai ke mic ka sunna rok do ya chalu karo.
 */
class Voice(
    private val ctx: Context,
    private val onInfo: (String) -> Unit,
    private val onSpeaking: (Boolean) -> Unit
) {
    private class Item(val text: String, val onDone: () -> Unit) {
        var id: String = ""
    }

    private val main = Handler(Looper.getMainLooper())
    private var tts: TextToSpeech? = null
    @Volatile private var ttsReady = false
    @Volatile private var ttsInitDone = false
    private val items = ArrayDeque<Item>()      // sirf main thread
    private var current: Item? = null           // sirf main thread
    private val byId = ConcurrentHashMap<String, Item>()
    private val started = ConcurrentHashMap.newKeySet<String>()
    private var failStreak = 0

    private val ttsListener = object : UtteranceProgressListener() {
        override fun onStart(id: String?) {
            if (id == null) return
            started.add(id)
            main.post { failStreak = 0 }
        }
        override fun onDone(id: String?) { finish(id) }
        @Deprecated("Deprecated in Java")
        override fun onError(id: String?) { finish(id) }
        override fun onError(id: String?, errorCode: Int) { finish(id) }
        override fun onStop(id: String?, interrupted: Boolean) { finish(id) }
    }

    init {
        initTts()
    }

    private fun initTts() {
        ttsInitDone = false
        ttsReady = false
        val engine = TextToSpeech(ctx) { status -> main.post { onTtsInit(status) } }
        engine.setOnUtteranceProgressListener(ttsListener)
        tts = engine
    }

    private fun reinitTts() {
        onInfo("Awaaz ka engine dobara shuru kar rahi hoon.")
        try { tts?.shutdown() } catch (e: Exception) {}
        tts = null
        initTts()
    }

    private fun onTtsInit(status: Int) {
        ttsInitDone = true
        if (status != TextToSpeech.SUCCESS) {
            onInfo("Text-to-speech shuru nahi hua. Google Text-to-speech app on karo.")
            return
        }
        val t = tts ?: return
        fun ok(r: Int?) = r != null && r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED
        ttsReady = ok(t.setLanguage(Locale("ur", "PK"))) || ok(t.setLanguage(Locale("hi", "IN")))
        t.setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ASSISTANT)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build()
        )
        t.setSpeechRate(1.1f)
        t.setPitch(1.15f)
        if (!ttsReady) onInfo("Urdu/Hindi awaaz nahi mili. Google Text-to-speech mein Hindi voice install karo.")
    }

    private fun finish(id: String?) {
        if (id == null) return
        val item = byId[id] ?: return
        main.post { complete(item) }
    }

    /** Bolo. flush = true: jo bol rahi hai use rok kar ye bolo. onDone: is line ke khatam hone par. */
    fun say(text: String, flush: Boolean = false, onDone: () -> Unit = {}) {
        if (text.isBlank()) { onDone(); return }
        if (flush) {
            items.clear()
            try { tts?.stop() } catch (e: Exception) {}
        }
        items.addLast(Item(text, onDone))
        pump()
    }

    /** Agli line bolo. Queue khali ho to sunna dobara chalu. Sirf main thread par. */
    private fun pump() {
        if (current != null) return
        val item = items.firstOrNull()
        if (item == null) {
            onSpeaking(false)
            return
        }
        if (!ttsReady) {
            if (!ttsInitDone) {
                main.postDelayed({ pump() }, 300)
                return
            }
            items.removeFirst()
            onInfo("Awaaz taiyaar nahi. Google Text-to-speech mein Hindi voice install karo.")
            item.onDone()
            pump()
            return
        }
        items.removeFirst()
        current = item
        onSpeaking(true)
        val id = System.nanoTime().toString()
        item.id = id
        byId[id] = item

        // Safety: khatam ka signal na aaye to 30 second baad aage barho.
        main.postDelayed({
            if (current === item) {
                onInfo("Awaaz atak gayi, aage badh rahi hoon.")
                complete(item)
            }
        }, 30_000)
        // Agar 4 second mein awaaz shuru na ho to ye line chhod do.
        main.postDelayed({
            if (current === item && !started.contains(id)) {
                onInfo("Awaaz shuru nahi hui. Google Text-to-speech ki settings check karo.")
                failStreak++
                if (failStreak >= 2) {
                    failStreak = 0
                    reinitTts()
                }
                complete(item)
            }
        }, 4_000)
        main.postDelayed({
            val r = tts?.speak(item.text, TextToSpeech.QUEUE_ADD, null, id)
            if (r == TextToSpeech.ERROR) {
                onInfo("Awaaz chalane mein masla hua.")
                complete(item)
            }
        }, 50)
    }

    private fun complete(item: Item) {
        if (current !== item) return
        current = null
        byId.remove(item.id)
        started.remove(item.id)
        item.onDone()
        pump()
    }

    fun shutdown() {
        main.removeCallbacksAndMessages(null)
        try { tts?.shutdown() } catch (e: Exception) {}
    }
}
