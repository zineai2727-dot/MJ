package com.waqas.mj

import android.content.Context
import android.os.Handler
import android.os.Looper
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.RecognitionListener
import org.vosk.android.SpeechService
import java.io.File
import java.util.concurrent.TimeUnit
import java.util.zip.ZipInputStream

/**
 * Vosk: offline Hindi awaaz. Mic ek hi session mein chalta hai (baar baar on/off nahi).
 * MJ bol rahi ho to setPause(true), bolne ke baad setPause(false).
 * Model pehli dafa official site se download hota hai (~42 MB), phir phone par save ho jata hai.
 */
class Ears(
    private val ctx: Context,
    private val onText: (String) -> Unit,
    private val onInfo: (String) -> Unit
) {
    companion object {
        const val MODEL_URL = "https://alphacephei.com/vosk/models/vosk-model-small-hi-0.22.zip"
        const val MODEL_DIR = "model"
        const val RATE = 16000.0f
    }

    private val main = Handler(Looper.getMainLooper())
    private val http = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(120, TimeUnit.SECONDS)
        .build()
    private var model: Model? = null
    private var service: SpeechService? = null
    private var paused = false
    @Volatile var ready = false
        private set

    /** Model load. Pehle se saved ho to seedha load, warna download karke save. */
    fun load(onReady: () -> Unit) {
        val target = File(ctx.filesDir, MODEL_DIR)
        Thread {
            try {
                if (!File(target, "am").isDirectory) {
                    main.post { onInfo("Vosk model download ho raha hai (~42 MB). Internet on rakho.") }
                    download(target)
                }
                val m = Model(target.absolutePath)
                main.post { model = m; ready = true; onReady() }
            } catch (e: Exception) {
                main.post { onInfo("Vosk model nahi mila: ${e.message}. Internet check karke app dobara shuru karo.") }
            }
        }.start()
    }

    private fun download(target: File) {
        val zip = File(ctx.cacheDir, "vosk-hi.zip")
        val req = Request.Builder().url(MODEL_URL).build()
        http.newCall(req).execute().use { r ->
            if (!r.isSuccessful) throw IllegalStateException("download HTTP ${r.code}")
            val body = r.body ?: throw IllegalStateException("khali jawab")
            body.byteStream().use { input -> zip.outputStream().use { input.copyTo(it) } }
        }
        val tmp = File(ctx.filesDir, "unzip-tmp")
        tmp.deleteRecursively()
        tmp.mkdirs()
        unzip(zip, tmp)
        zip.delete()
        // Zip ke andar ek folder hota hai (vosk-model-small-hi-0.22); usko "model" banao.
        val inner = tmp.listFiles()?.firstOrNull { it.isDirectory } ?: tmp
        target.deleteRecursively()
        if (!inner.renameTo(target)) throw IllegalStateException("model folder move nahi hua")
        tmp.deleteRecursively()
    }

    private fun unzip(zip: File, dest: File) {
        val base = dest.canonicalPath
        ZipInputStream(zip.inputStream().buffered()).use { zis ->
            var entry = zis.nextEntry
            while (entry != null) {
                val out = File(dest, entry.name)
                if (!out.canonicalPath.startsWith(base)) throw IllegalStateException("ghalat zip entry")
                if (entry.isDirectory) {
                    out.mkdirs()
                } else {
                    out.parentFile?.mkdirs()
                    out.outputStream().use { zis.copyTo(it) }
                }
                zis.closeEntry()
                entry = zis.nextEntry
            }
        }
    }

    fun start() {
        val m = model ?: return
        if (service != null) return
        try {
            val s = SpeechService(Recognizer(m, RATE), RATE)
            service = s
            s.startListening(listener)
            s.setPause(paused)
        } catch (e: Exception) {
            service = null
            onInfo("Mic shuru nahi hua: ${e.message}")
        }
    }

    /** MJ bolti ho to true (mic ka sunna rok do), bolne ke baad false. */
    fun setPaused(p: Boolean) {
        paused = p
        try { service?.setPause(p) } catch (e: Exception) {}
    }

    fun stop() {
        try { service?.stop() } catch (e: Exception) {}
        try { service?.shutdown() } catch (e: Exception) {}
        service = null
    }

    private val listener = object : RecognitionListener {
        override fun onPartialResult(hypothesis: String?) {}

        override fun onResult(hypothesis: String?) {
            val text = try {
                JSONObject(hypothesis ?: "").optString("text")
            } catch (e: Exception) {
                ""
            }.trim()
            if (text.isNotEmpty() && !paused) main.post { onText(text) }
        }

        override fun onFinalResult(hypothesis: String?) {}

        override fun onError(e: Exception?) {
            main.post {
                onInfo("Mic (Vosk) masla: ${e?.message}. Dobara shuru kar rahi hoon.")
                stop()
                main.postDelayed({ start() }, 1000)
            }
        }

        override fun onTimeout() {}
    }
}
