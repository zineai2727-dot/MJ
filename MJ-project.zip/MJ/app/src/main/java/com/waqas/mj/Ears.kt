package com.waqas.mj

import android.content.Context
import android.os.Handler
import android.os.Looper
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.RecognitionListener
import org.vosk.android.SpeechService
import java.io.File
import java.util.concurrent.TimeUnit
import java.util.zip.ZipInputStream

/**
 * Vosk: offline Hindi awaaz. Mic ek hi session mein chalta hai (baar baar on/off nahi).
 * MJ bol rahi ho to setPause(true), bolne ke baad setPause(false).
 * Model: pehle filesDir/model. Na ho to filesDir/vosk-hi.zip (user ki chuni hui zip) khol-ta hai,
 * warna official site se download karta hai (progress log mein dikhta hai).
 */
class Ears(
    private val ctx: Context,
    private val onText: (String) -> Unit,
    private val onInfo: (String) -> Unit
) {
    companion object {
        const val MODEL_URL = "https://alphacephei.com/vosk/models/vosk-model-small-hi-0.22.zip"
        const val MODEL_DIR = "model"
        const val LOCAL_ZIP = "vosk-hi.zip"
        const val RATE = 16000.0f

        // Model ek dafa load ho to service dobara chalne par phir load nahi hota.
        @Volatile
        private var cached: Model? = null
    }

    private val main = Handler(Looper.getMainLooper())
    private val http = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(120, TimeUnit.SECONDS)
        .build()
    private var model: Model? = null
    private var service: SpeechService? = null
    private var paused = false
    @Volatile var ready = false
        private set

    /** Model load. Pehle se saved ho to seedha load. */
    fun load(onReady: () -> Unit) {
        val target = File(ctx.filesDir, MODEL_DIR)
        cached?.let { m ->
            model = m
            ready = true
            main.post { onReady() }
            return
        }
        Thread {
            try {
                if (!File(target, "am").isDirectory) {
                    val local = File(ctx.filesDir, LOCAL_ZIP)
                    if (local.exists()) {
                        main.post { onInfo("Model ki zip mili, khol rahi hoon...") }
                    } else {
                        main.post { onInfo("Model download shuru (~42 MB). Progress yahin dikhega.") }
                        download(local)
                    }
                    install(local, target)
                }
                val m = Model(target.absolutePath)
                cached = m
                main.post { model = m; ready = true; onReady() }
            } catch (e: Exception) {
                main.post {
                    onInfo("Model masla: ${e.javaClass.simpleName}: ${e.message}. " +
                        "Agar download na ho to 'Model zip chunein' button se file de do.")
                }
            }
        }.start()
    }

    /** Download karte waqt har 10% (ya har 5 MB) par log mein progress. */
    private fun download(dest: File) {
        val part = File(ctx.filesDir, "$LOCAL_ZIP.part")
        val req = Request.Builder().url(MODEL_URL).build()
        http.newCall(req).execute().use { r ->
            if (!r.isSuccessful) throw IllegalStateException("server ne HTTP ${r.code} diya")
            val body = r.body ?: throw IllegalStateException("khali jawab aaya")
            val total = body.contentLength()
            val step = if (total > 0) total / 10 else 5L * 1024 * 1024
            var got = 0L
            var lastReported = 0L
            body.byteStream().use { input ->
                part.outputStream().use { out ->
                    val buf = ByteArray(64 * 1024)
                    while (true) {
                        val n = input.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        got += n
                        if (got - lastReported >= step) {
                            lastReported = got
                            val msg = if (total > 0) {
                                "${got * 100 / total}%  (${got / 1048576} MB / ${total / 1048576} MB)"
                            } else {
                                "${got / 1048576} MB"
                            }
                            main.post { onInfo("Model download: $msg") }
                        }
                    }
                }
            }
        }
        if (dest.exists()) dest.delete()
        if (!part.renameTo(dest)) throw IllegalStateException("download file save nahi hui")
        main.post { onInfo("Download mukammal. Model khol rahi hoon...") }
    }

    /** Zip khol kar filesDir/model banata hai. Zip ke andar ek folder hota hai, usko "model" banate hain. */
    private fun install(zip: File, target: File) {
        if (!zip.exists()) throw IllegalStateException("zip file nahi mili")
        val tmp = File(ctx.filesDir, "unzip-tmp")
        tmp.deleteRecursively()
        tmp.mkdirs()
        unzip(zip, tmp)
        val inner = tmp.listFiles()?.firstOrNull { it.isDirectory } ?: tmp
        target.deleteRecursively()
        if (!inner.renameTo(target)) throw IllegalStateException("model folder move nahi hua")
        tmp.deleteRecursively()
        zip.delete()
        main.post { onInfo("Model taiyaar ho gaya. Load ho raha hai...") }
    }

    private fun unzip(zip: File, dest: File) {
        val base = dest.canonicalPath
        ZipInputStream(zip.inputStream().buffered()).use { zis ->
            var entry = zis.nextEntry
            while (entry != null) {
                val out = File(dest, entry.name)
                if (!out.canonicalPath.startsWith(base)) throw IllegalStateException("ghalat zip entry")
                if (entry.isDirectory) {
                    out.mkdirs()
                } else {
                    out.parentFile?.mkdirs()
                    out.outputStream().use { zis.copyTo(it) }
                }
                zis.closeEntry()
                entry = zis.nextEntry
            }
        }
    }

    fun start() {
        val m = model ?: return
        if (service != null) return
        try {
            val s = SpeechService(Recognizer(m, RATE), RATE)
            service = s
            s.startListening(listener)
            s.setPause(paused)
        } catch (e: Exception) {
            service = null
            onInfo("Mic shuru nahi hua: ${e.message}")
        }
    }

    /** MJ bolti ho to true (mic ka sunna rok do), bolne ke baad false. */
    fun setPaused(p: Boolean) {
        paused = p
        try { service?.setPause(p) } catch (e: Exception) {}
    }

    fun stop() {
        try { service?.stop() } catch (e: Exception) {}
        try { service?.shutdown() } catch (e: Exception) {}
        service = null
    }

    private val listener = object : RecognitionListener {
        override fun onPartialResult(hypothesis: String?) {}

        override fun onResult(hypothesis: String?) {
            val text = try {
                JSONObject(hypothesis ?: "").optString("text")
            } catch (e: Exception) {
                ""
            }.trim()
            if (text.isNotEmpty() && !paused) main.post { onText(text) }
        }

        override fun onFinalResult(hypothesis: String?) {}

        override fun onError(e: Exception?) {
            main.post {
                onInfo("Mic (Vosk) masla: ${e?.message}. Dobara shuru kar rahi hoon.")
                stop()
                main.postDelayed({ start() }, 1000)
            }
        }

        override fun onTimeout() {}
    }
}
