package com.waqas.mj

import android.accessibilityservice.AccessibilityService
import android.content.Context

/**
 * Seedhe chhote hukm bina AI ke (foran chalte hain, API ki limit kharch nahi hoti).
 * Return: Triple(hindi script, urdu script, roman) ya null agar ye seedha hukm nahi.
 */
object LocalIntents {

    private fun has(t: String, vararg words: String) = words.any { t.contains(it) }

    fun tryHandle(ctx: Context, svc: MJService?, raw: String): Triple<String, String, String>? {
        val t = raw.lowercase().trim()
        val wordCount = t.split(Regex("\\s+")).size

        // ---- Torch ----
        if (has(t, "torch", "ٹارچ", "टॉर्च", "टार्च", "flashlight", "flash light", "فلیش", "फ्लैश")) {
            val off = has(t, "off", "آف", "بند", "बंद", "ऑफ", "बुझा", "بجھا")
            val on = has(t, " on", "آن", "चालू", "ऑन", "जला", "جلا", "کھول", "खोल")
            if (off) {
                return if (Phone.torch(ctx, false))
                    Triple("ठीक है बॉस, टॉर्च बंद कर दी", "ٹھیک ہے باس، ٹارچ بند کر دی", "Theek hai boss, torch band kar di")
                else null
            }
            if (on || wordCount <= 3) {
                return if (Phone.torch(ctx, true))
                    Triple("ठीक है बॉस, टॉर्च जला दी", "ٹھیک ہے باس، ٹارچ جلا دی", "Theek hai boss, torch jala di")
                else null
            }
        }

        // ---- Awaaz (volume) ----
        if (has(t, "آواز", "आवाज", "volume", "وولیم", "वॉल्यूम")) {
            val how = when {
                has(t, "mute", "میوٹ", "म्यूट", "خاموش", "बंद", "بند") -> "mute"
                has(t, "full", "max", "فل", "फुल", "پوری", "पूरी") -> "max"
                has(t, "کم", "कम", "घटा", "down", "ہلکی", "धीमी", "آہستہ") -> "down"
                has(t, "بڑھا", "बढ़ा", "बढा", "زیادہ", "ज़्यादा", "ज्यादा", "तेज़", "तेज", "up", "اونچی") -> "up"
                else -> null
            }
            if (how != null && Phone.volume(ctx, how)) {
                return Triple("जी बॉस, आवाज़ ठीक कर दी", "جی باس، آواز ٹھیک کر دی", "Ji boss, awaaz theek kar di")
            }
        }

        // ---- Home / Back (sirf chhote hukm, aur Accessibility chahiye) ----
        if (svc != null && wordCount <= 4) {
            if (has(t, "home", "ہوم", "होम")) {
                svc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_HOME)
                return Triple("ठीक है बॉस", "ٹھیک ہے باس", "Theek hai boss")
            }
            if (has(t, "back", "بیک", "बैक", "پیچھے", "पीछे", "واپس", "वापस")) {
                svc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK)
                return Triple("ठीक है बॉस", "ٹھیک ہے باس", "Theek hai boss")
            }
        }
        return null
    }
}
