package com.waqas.mj

import android.Manifest
import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/** Control panel: ek Start button, key, setup aur log. Asli kaam ListenService karti hai. */
class MainActivity : Activity() {

    private val prefs by lazy { getSharedPreferences("mj", MODE_PRIVATE) }
    private lateinit var keyBox: EditText
    private lateinit var statusView: TextView
    private lateinit var mainBtn: Button
    private lateinit var logView: TextView
    private lateinit var outer: ScrollView

    private val ink = "#1B2430"
    private val mute = "#6B7785"
    private val primary = "#1F4E79"
    private val accent = "#0F9D8A"
    private val danger = "#B3261E"

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, radius: Int, stroke: Int? = null) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radius).toFloat()
        if (stroke != null) setStroke(dp(1), stroke)
    }

    private fun label(t: String, size: Float = 13f, color: String = mute, bold: Boolean = false) =
        TextView(this).apply {
            text = t
            textSize = size
            setTextColor(Color.parseColor(color))
            if (bold) typeface = Typeface.DEFAULT_BOLD
        }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = rounded(Color.WHITE, 16, Color.parseColor("#E3E7ED"))
        setPadding(dp(16), dp(16), dp(16), dp(16))
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(14) }
    }

    private fun outlineBtn(t: String, onClick: () -> Unit) = Button(this).apply {
        text = t
        isAllCaps = false
        setTextColor(Color.parseColor(primary))
        background = rounded(Color.WHITE, 12, Color.parseColor(primary))
        layoutParams = LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(8) }
        setOnClickListener { onClick() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#F4F6F9"))
            setPadding(dp(20), dp(24), dp(20), dp(24))
        }

        // Header
        root.addView(label("MJ", 34f, primary, true))
        root.addView(label("Aap ki assistant  ·  wake word: \"MJ\"", 14f))

        statusView = label("Ruki hui", 15f, accent, true).apply { setPadding(0, dp(14), 0, 0) }
        root.addView(statusView)

        // Start / Stop
        mainBtn = Button(this).apply {
            textSize = 17f
            isAllCaps = false
            setTextColor(Color.WHITE)
            layoutParams = LinearLayout.LayoutParams(-1, dp(58)).apply { topMargin = dp(12) }
            setOnClickListener { toggle() }
        }
        root.addView(mainBtn)

        // API key
        val keyCard = card()
        keyCard.addView(label("Gemini API key", 13f, mute, true))
        keyBox = EditText(this).apply {
            hint = "AIza... ya AQ... wali key"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setText(prefs.getString("key", ""))
            background = rounded(Color.parseColor("#F4F6F9"), 10, Color.parseColor("#E3E7ED"))
            setPadding(dp(12), dp(10), dp(12), dp(10))
            setTextColor(Color.parseColor(ink))
        }
        keyCard.addView(keyBox)
        root.addView(keyCard)

        // Setup
        val setupCard = card()
        setupCard.addView(label("Setup", 13f, mute, true))
        setupCard.addView(outlineBtn("Accessibility ON karo") {
            open(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        setupCard.addView(outlineBtn("Battery: unrestricted karo") {
            open(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        })
        setupCard.addView(outlineBtn("Default assistant settings kholo") {
            open(Intent(Settings.ACTION_VOICE_INPUT_SETTINGS))
        })
        root.addView(setupCard)

        // Log
        val logCard = card()
        logCard.addView(label("Activity", 13f, mute, true))
        logView = TextView(this).apply {
            textSize = 14f
            setTextColor(Color.parseColor(ink))
            setPadding(0, dp(8), 0, 0)
        }
        logCard.addView(logView)
        root.addView(logCard)

        outer = ScrollView(this).apply { addView(root) }
        setContentView(outer)

        requestNeeded()
    }

    override fun onResume() {
        super.onResume()
        logView.text = LogBus.history().joinToString("\n\n")
        refresh()
        LogBus.listener = { line ->
            runOnUiThread {
                logView.append("\n\n$line")
                refresh()
                outer.post { outer.fullScroll(View.FOCUS_DOWN) }
            }
        }
    }

    override fun onPause() {
        LogBus.listener = null
        super.onPause()
    }

    private fun refresh() {
        if (!ListenService.running) {
            statusView.text = "Ruki hui"
            statusView.setTextColor(Color.parseColor(mute))
            mainBtn.text = "Start"
            mainBtn.background = rounded(Color.parseColor(accent), 14)
        } else {
            statusView.text = if (Agent.isBusy()) "Kaam ho raha hai..." else "Sun rahi hoon. \"MJ\" bolo."
            statusView.setTextColor(Color.parseColor(accent))
            mainBtn.text = "Band karo"
            mainBtn.background = rounded(Color.parseColor(danger), 14)
        }
    }

    private fun toggle() {
        if (ListenService.running) {
            startService(Intent(this, ListenService::class.java).setAction(ListenService.ACTION_QUIT))
            outer.postDelayed({ refresh() }, 400)
        } else {
            start()
        }
    }

    private fun start() {
        val key = keyBox.text.toString().trim()
        if (key.isEmpty()) { toast("Pehle API key likho."); return }
        prefs.edit().putString("key", key).apply()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            toast("Microphone ki ijazat do, phir Start dabao.")
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 2)
            return
        }
        startForegroundService(Intent(this, ListenService::class.java))
        outer.postDelayed({ refresh() }, 400)
    }

    private fun requestNeeded() {
        val perms = mutableListOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.CALL_PHONE,
            Manifest.permission.READ_CONTACTS
        )
        if (Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.POST_NOTIFICATIONS)
        requestPermissions(perms.toTypedArray(), 1)
    }

    private fun open(intent: Intent) {
        try {
            startActivity(intent)
        } catch (e: ActivityNotFoundException) {
            toast("Ye setting is phone par nahi mili.")
        }
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
}
