package com.waqas.mj

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity(), Agent.Ui {

    private lateinit var voice: Voice
    private lateinit var logView: TextView
    private lateinit var keyBox: EditText

    private val prefs by lazy { getSharedPreferences("mj", Context.MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }

        keyBox = EditText(this).apply {
            hint = "Gemini API key (AIza...)"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setText(prefs.getString("key", ""))
        }
        val accBtn = Button(this).apply {
            text = "1) Accessibility service ON karo"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        val talkBtn = Button(this).apply {
            text = "2) MJ se bolo"
            setOnClickListener {
                prefs.edit().putString("key", keyBox.text.toString().trim()).apply()
                voice.listen()
            }
        }
        val stopBtn = Button(this).apply {
            text = "Roko"
            setOnClickListener { Agent.stop() }
        }
        logView = TextView(this).apply { textSize = 15f }
        val scroll = ScrollView(this).apply { addView(logView) }

        root.addView(keyBox)
        root.addView(accBtn)
        root.addView(talkBtn)
        root.addView(stopBtn)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)

        voice = Voice(this, { Agent.onHeard(it) }, { log(it) })
        Agent.ui = this

        requestPermissions(
            arrayOf(
                Manifest.permission.RECORD_AUDIO,
                Manifest.permission.CALL_PHONE,
                Manifest.permission.READ_CONTACTS
            ), 1
        )
    }

    override fun onDestroy() {
        voice.shutdown()
        super.onDestroy()
    }

    // ---- Agent.Ui ----
    override fun log(line: String) {
        runOnUiThread { logView.append(line + "\n\n") }
    }

    override fun speak(urdu: String, onDone: () -> Unit) {
        runOnUiThread { voice.speak(urdu, onDone) }
    }

    override fun listen() {
        runOnUiThread { voice.listen() }
    }

    override fun apiKey(): String = prefs.getString("key", "").orEmpty()
}
