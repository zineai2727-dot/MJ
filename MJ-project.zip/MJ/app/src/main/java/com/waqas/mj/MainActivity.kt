package com.waqas.mj

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/** Sirf control panel: asli kaam ListenService background mein karti hai. */
class MainActivity : Activity() {

    private lateinit var logView: TextView
    private lateinit var scroll: ScrollView
    private lateinit var keyBox: EditText
    private lateinit var keyTts: EditText

    private val prefs by lazy { getSharedPreferences("mj", Context.MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }

        fun btn(label: String, onClick: () -> Unit) = Button(this).apply {
            text = label
            setOnClickListener { onClick() }
        }

        keyBox = EditText(this).apply {
            hint = "API key (Groq gsk_... ya Gemini AQ/AIza...)"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setText(prefs.getString("key", ""))
        }
        logView = TextView(this).apply { textSize = 15f }
        scroll = ScrollView(this).apply { addView(logView) }

        keyTts = EditText(this).apply {
            hint = "Gemini key (sirf awaaz ke liye, optional)"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setText(prefs.getString("tts_key", ""))
        }
        root.addView(keyBox)
        root.addView(keyTts)
        root.addView(btn("1) Accessibility service ON karo") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        root.addView(btn("2) MJ chalu karo (background)") { startMj() })
        val wakeBtn = btn("") { }
        fun refreshWake() {
            wakeBtn.text = if (prefs.getBoolean("wake_always", false))
                "Hamesha \"MJ\" sunna: ON (mic jhatke de sakta hai)"
            else
                "Hamesha \"MJ\" sunna: OFF (notification se \"Bolo\" dabao)"
        }
        wakeBtn.setOnClickListener {
            prefs.edit().putBoolean("wake_always", !prefs.getBoolean("wake_always", false)).apply()
            refreshWake()
            if (ListenService.running) send(ListenService.ACTION_APPLY)
        }
        refreshWake()
        val gemBtn = btn("") { }
        fun refreshGem() {
            gemBtn.text = if (prefs.getBoolean("gemini_voice", true))
                "Awaaz: Gemini Sulafat (zinda awaaz) ON"
            else
                "Awaaz: Android (backup) - Gemini OFF"
        }
        gemBtn.setOnClickListener {
            prefs.edit().putBoolean("gemini_voice", !prefs.getBoolean("gemini_voice", true)).apply()
            refreshGem()
        }
        refreshGem()
        root.addView(btn("MJ se abhi bolo") { send(ListenService.ACTION_TALK) })
        root.addView(wakeBtn)
        root.addView(gemBtn)
        root.addView(btn("Awaaz badlo (female chuno)") { send(ListenService.ACTION_NEXT_VOICE) })
        root.addView(btn("Kaam roko") { send(ListenService.ACTION_STOP_TASK) })
        root.addView(btn("MJ band karo") { send(ListenService.ACTION_QUIT) })
        root.addView(btn("Battery limit hatao (MJ band na ho)") {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        })
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)

        val perms = mutableListOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.CALL_PHONE,
            Manifest.permission.READ_CONTACTS
        )
        if (Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.POST_NOTIFICATIONS)
        requestPermissions(perms.toTypedArray(), 1)
    }

    override fun onResume() {
        super.onResume()
        logView.text = LogBus.history().joinToString("\n\n") + "\n\n"
        scrollToEnd()
        LogBus.listener = { line ->
            runOnUiThread {
                logView.append(line + "\n\n")
                scrollToEnd()
            }
        }
    }

    override fun onPause() {
        LogBus.listener = null
        super.onPause()
    }

    private fun scrollToEnd() {
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()

    private fun startMj() {
        val key = keyBox.text.toString().trim()
        if (key.isEmpty()) { toast("Pehle upar API key likho."); return }
        prefs.edit()
            .putString("key", key)
            .putString("tts_key", keyTts.text.toString().trim())
            .apply()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            toast("Microphone ki ijazat do, phir dobara dabao.")
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 2)
            return
        }
        startForegroundService(Intent(this, ListenService::class.java))
    }

    private fun send(action: String) {
        if (!ListenService.running) { toast("Pehle \"MJ chalu karo\" dabao."); return }
        startService(Intent(this, ListenService::class.java).setAction(action))
    }
}
