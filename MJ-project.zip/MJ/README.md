# MJ - Urdu voice assistant (Android)

## Kaise chalta hai
1. **Start** dabao. MJ background mein chalti hai (notification dikhti hai).
2. **"MJ"** bolo, phir hukm do: "MJ torch on karo", "MJ WhatsApp kholo", "MJ Ammi ko call karo".
3. Kaam ke baad MJ kuch der jagi rehti hai, phir khamosh ho jati hai. Dobara "MJ" bolo.
4. Message bhejne ya call se pehle MJ poochti hai. "haan" bolo to karti hai.
5. Chhote hukm (torch wagera) bina AI ke foran chalte hain.

## Setup
1. API key (Gemini) paste karo.
2. **Accessibility ON karo** (screen padhne aur click ke liye zaroori).
3. **Battery: unrestricted karo** (warna phone MJ ko band kar sakta hai).
4. Permissions Allow karo (mic, call, contacts, notifications).
5. "Default assistant settings" button sirf settings kholta hai. Normal app system ki default assistant nahi ban sakti.

## Model
- `Brain.kt` mein `MODEL = "gemini-flash-lite-latest"`. Badalna ho to wahan badlo.

## Files
- `ListenService.kt`: background, "MJ" wake word, jagna aur sona
- `Agent.kt`: screen > AI > action loop, sawal-jawab
- `LocalIntents.kt`: bina AI ke chhote hukm
- `Brain.kt`: Gemini API aur MJ ki shakhsiyat
- `MJService.kt`: screen padhna, click, type, scroll
- `Phone.kt`: app kholna, call, torch, volume
- `Voice.kt`: bolna (Urdu/Hindi awaaz) aur sunna
- `MainActivity.kt`: control panel

## Limits
- Android ka built-in speech recognizer har jumle ke baad band hota hai, is liye mic par thora jhatka aur beep aa sakta hai. Behtar hal offline wake word (Vosk/Porcupine) hai.
- Gemini free plan mein din mein limited requests hoti hain.
