# MJ - Urdu voice assistant (Android)

## Kaise chalti hai
1. **Start** button dabao. MJ sunna shuru karti hai (notification dikhti hai).
2. Hukm do: "WhatsApp kholo", "King Khan ki chat kholo", "YouTube par gaana chalao", "torch on karo".
3. Kaam ke dauran MJ sawal poochti hai (kis ki chat, kya likhun, bhej doon). Jawab do.
4. Kuch na bolo to 10 second baad MJ so jati hai. Dobara Start dabao.
5. "Ruko" bol kar ya notification mein "Roko" dabao to kaam ruk jata hai.

## Setup
1. Gemini API key paste karo.
2. Accessibility ON karo.
3. Battery: unrestricted karo.
4. Permissions Allow karo (mic, call, contacts, notifications).

## Files
- `ListenService.kt`: session (Start se shuru, 10 second idle par band)
- `Agent.kt`: screen > AI > action loop, sawal-jawab, local hukm
- `LocalIntents.kt`: torch wagera bina AI ke
- `Brain.kt`: Gemini (gemini-flash-lite-latest) aur flows
- `MJService.kt`: screen padhna, click, type, enter, scroll
- `Phone.kt`: app kholna (Urdu/Hindi naam bhi), call, torch, volume
- `Voice.kt`: bolna aur sunna
- `MainActivity.kt`: control panel

## Limits
- Android ka speech recognizer Urdu mein kabhi galat likhta hai. Behtar hal Whisper (Groq) hai.
- Gemini free plan mein din mein requests limited hain.
- Session ke dauran TV ya doosron ki awaaz bhi hukm samjhi ja sakti hai.
