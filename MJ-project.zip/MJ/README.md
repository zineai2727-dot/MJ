# MJ - Urdu voice assistant jo phone control karti hai (Android)

## Chalane ke steps
1. Android Studio mein `MJ` folder kholo (File > Open). Gradle sync hone do.
2. Android phone USB se lagao (Developer options + USB debugging on) aur Run dabao.
3. App kholo, permissions "Allow" karo (mic, call, contacts).
4. App mein apni Anthropic API key likho (console.anthropic.com se).
5. "Accessibility service ON karo" dabao > MJ chuno > ON.
   (Android 13+ par restricted setting ho to: Settings > Apps > MJ > 3 dots > "Allow restricted settings".)
6. Phone ki Settings > Text-to-speech mein Google engine ki **Urdu (Pakistan)** awaaz download karo.
7. "MJ se bolo" dabao aur hukm do, jaise:
   - "torch on karo"
   - "WhatsApp kholo"
   - "Ammi ko call karo"
   - "King Khan ki chat kholo" (WhatsApp khula ho to) > "likho: kal milte hain" > "bhej do"

## Files
- `Agent.kt`: loop (screen > AI > action) aur confirmation ("ask")
- `Brain.kt`: Claude API call + MJ ki shakhsiyat (system prompt). Model yahan badlo.
- `MJService.kt`: Accessibility: screen padhna, click, type, scroll
- `Phone.kt`: app kholna, call, torch, volume
- `Voice.kt`: Urdu sunna aur bolna
- `MainActivity.kt`: simple screen

## Dhyan rakho
- Ye starter hai, abhi test nahi hua. Pehle apne phone par try karo aur jo error aaye mujhe bhej do.
- Send/call/delete se pehle MJ confirmation maangti hai; ye rule `Brain.kt` ke SYSTEM prompt mein hai, usay mat hatao.
- Female awaaz: Android sirf locale ka default voice deta hai. Phone ki TTS settings mein female Urdu voice chuno. Zyada achi awaaz ke liye baad mein ElevenLabs jaisi service lag sakti hai.
- API key phone mein SharedPreferences mein hai. Play Store ke liye apna server rakho, key app mein mat rakho.
- Har step par API call hoti hai, is liye thora waqt aur kharcha lagta hai.
- Password, OTP, bank ki screens par MJ ko kaam na karne do.
