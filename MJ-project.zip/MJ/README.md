# MJ - Urdu voice assistant jo phone control karti hai (Android)

## Kaise kaam karti hai
- **MJ chalu karo** dabane par MJ background mein chalti hai (notification dikhti hai). Mic **band** rehta hai.
- Jagane ke liye notification mein **"Bolo"** dabao (ya app ka "MJ se abhi bolo"). Phir "MJ" kahe baghair hukm do.
- Agar "Hamesha MJ sunna" ON karo to "MJ" bolne se bhi jagti hai (lekin mic baar baar on-off hota hai).
- Hukm bolne ke baad **1.5 second** khamoshi ka intezar karti hai. Is dauran kuch aur bolo to wo isi hukm mein jur jata hai.
- Aap 10 second kuch na bolo to MJ so jati hai (mic band). Jab tak bolte raho, jagi rehti hai.
- Kaam ke dauran mic band rehta hai; rokne ke liye notification mein "Roko" dabao.
- MJ aap ko "boss" bulati hai, pyar se baat karti hai, kaam ke baad poochti hai "aur kuch?".
- Send/call/delete se pehle confirmation poochti hai.

## Chalane ke steps
1. APK install karo (GitHub Actions se bana).
2. Permissions "Allow": mic, call, contacts, notifications.
3. API key paste karo.
4. "Accessibility service ON karo" > MJ > ON.
   (Restricted ho to: Settings > Apps > MJ > 3 dots > Allow restricted settings.)
5. "Awaaz badlo (female chuno)" dabate jao jab tak pasand ki awaaz na mile.
6. "MJ chalu karo (background)" dabao.
7. "Battery limit hatao" dabao aur MJ ko "Unrestricted" karo, warna phone band kar sakta hai.
8. Ab "MJ torch on karo" bolo.

## Awaaz
- MJ Gemini ki zinda awaaz **Sulafat** mein bolti hai (wahi API key). Pehli baar sab tareeqe aazmati hai, jo chal jaye yaad rakhti hai.
- Gemini na chale (limit/busy) to Android ki awaaz backup mein bolti hai. App ka "Awaaz: Gemini..." button isay ON/OFF karta hai.
- Gemini ki awaaz mein har jumla ek chhoti API call hai (thora intezar + free limit kharch).

## Files
- `ListenService.kt`: background sunna, wake word, intezar, follow-up
- `Agent.kt`: loop (screen > AI > action), confirmation
- `Brain.kt`: Gemini API + MJ ki shakhsiyat. Models yahan badlo.
- `MJService.kt`: Accessibility: screen padhna, click, type, scroll
- `Phone.kt`: app kholna, call, torch, volume
- `Voice.kt`: lagataar sunna aur bolna (Gemini awaaz + Android backup)
- `GeminiTts.kt`: Gemini ki awaaz (Sulafat) banana
- `MainActivity.kt`: control panel

## Dhyan rakho
- Ye abhi test nahi hua. Jo error aaye bhej do.
- Wake word Android ke speech service se chalta hai: jab tak MJ chalu hai, aap ki awaaz Google ki speech service ko jati hai (internet aur battery lagti hai), aur kuch phones par sunna dobara shuru hone par halki beep aati hai. Behtar tareeqa offline wake-word engine (jaise Picovoice Porcupine) hai.
- Jab MJ jagi ho aur phone par gaana/video chal raha ho, to wo awaaz bhi hukm samjhi ja sakti hai. Isi liye follow-up sirf 7 second hai.
- Raftaar/intezar badalna ho to `ListenService.kt` ke upar ACTIVE_MS, FOLLOWUP_MS, DEBOUNCE_MS badlo.
