package com.waqas.mj

import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger

/**
 * Sunna (lagataar, background mein) aur bolna.
 * Bolna: pehle Gemini ki zinda awaaz (Sulafat); na chale to Android ki awaaz (backup).
 * speak() aur recognizer ke saare kaam main thread se karo. MJ bolte waqt sunna rukta hai
 * taake wo apni hi awaaz na sune.
 */
class Voice(
    private val ctx: Context,
    private val onHeard: (String) -> Unit,
    private val onInfo: (String) -> Unit
) {
    private val main = Handler(Looper.getMainLooper())
    private val prefs = ctx.getSharedPreferences("mj", Context.MODE_PRIVATE)
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private val callbacks = ConcurrentHashMap<String, () -> Unit>()
    private var recognizer: SpeechRecognizer? = null
    private var continuous = false
    private var suspended = false
    private var speaking = 0
    private val startRunnable = Runnable { startListening() }

    /** Khali ho to Gemini awaaz band, sirf Android awaaz. */
    @Volatile
    var geminiKey: String = ""

    private val speechExec = Executors.newSingleThreadExecutor()
    private val gen = AtomicInteger(0)

    @Volatile
    private var track: AudioTrack? = null

    private val cache = object : LinkedHashMap<String, GeminiTts.Audio>(32, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, GeminiTts.Audio>?): Boolean =
            size > 40
    }

    init {
        tts = TextToSpeech(ctx) { status ->
            if (status == TextToSpeech.SUCCESS) {
                // Pehle Urdu, na mile to Hindi awaaz (bolchaal mein lagbhag ek hi hai).
                fun ok(r: Int?) = r != null && r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED
                ttsReady = ok(tts?.setLanguage(Locale("ur", "PK"))) || ok(tts?.setLanguage(Locale("hi", "IN")))
                if (!ttsReady) onInfo("Hindi/Urdu awaaz install nahi (backup awaaz). Settings > Text-to-speech > Google > Hindi.")
                applySavedVoice()
                tts?.setSpeechRate(1.15f)
                tts?.setPitch(1.2f)
            }
        }
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onDone(id: String?) { id?.let { callbacks.remove(it)?.invoke() } }
            @Deprecated("Deprecated in Java")
            override fun onError(id: String?) { id?.let { callbacks.remove(it)?.invoke() } }
            override fun onStop(id: String?, interrupted: Boolean) { id?.let { callbacks.remove(it)?.invoke() } }
        })
    }

    // ---------- Android awaaz chunna (backup awaaz) ----------
    private fun hindiVoices() = try {
        tts?.voices?.filter { it.locale.language == "hi" || it.locale.language == "ur" }
            ?.sortedBy { it.name } ?: emptyList()
    } catch (e: Exception) {
        emptyList()
    }

    private fun applySavedVoice() {
        val saved = prefs.getString("voice", null) ?: return
        hindiVoices().firstOrNull { it.name == saved }?.let { tts?.setVoice(it) }
    }

    /** Backup (Android) awaaz badalta hai. Gemini ki awaaz Sulafat par tay hai. */
    fun nextVoice() {
        if (geminiKey.isNotBlank()) onInfo("Abhi Gemini ki awaaz (Sulafat) chal rahi hai. Ye button sirf backup Android awaaz badalta hai.")
        val vs = hindiVoices()
        if (vs.isEmpty()) { onInfo("Koi Hindi/Urdu awaaz nahi mili. Settings > Text-to-speech > Google se download karo."); return }
        val i = vs.indexOfFirst { it.name == tts?.voice?.name }
        val v = vs[(i + 1) % vs.size]
        tts?.stop()
        tts?.setVoice(v)
        prefs.edit().putString("voice", v.name).apply()
        onInfo("Backup awaaz ${(i + 1) % vs.size + 1}/${vs.size}")
        val saved = geminiKey
        geminiKey = "" // namoona Android awaaz mein sunao
        speak("जी, मैं एमजे हूँ। यह मेरी आवाज़ है।")
        geminiKey = saved
    }

    // ---------- Bolna ----------
    /**
     * urdu: Android (backup) awaaz ke liye (Hindi script). rich: Gemini awaaz ke liye (Urdu script).
     * flush = true: jo bol rahi hai use rok kar naya jumla bolo (beech ke steps ke liye).
     */
    fun speak(urdu: String, flush: Boolean = false, rich: String? = null, onDone: () -> Unit = {}) {
        if (urdu.isBlank()) { onDone(); return }
        val finish = beginSpeech(onDone)
        if (flush) {
            gen.incrementAndGet()
            try { tts?.stop() } catch (e: Exception) {}
        }
        val key = geminiKey
        if (key.isBlank()) { speakAndroid(urdu, finish); return }

        val text = rich?.takeIf { it.isNotBlank() } ?: urdu
        val myGen = gen.get()
        speechExec.execute {
            if (myGen != gen.get()) { finish(); return@execute }
            val audio = fetchAudio(key, text)
            if (myGen != gen.get()) { finish(); return@execute }
            if (audio == null) { speakAndroid(urdu, finish); return@execute }
            play(audio, myGen)
            finish()
        }
    }

    /** Aam jumlon ki awaaz pehle se bana lo taake "जी बॉस" foran sunai de. */
    fun prewarm(texts: List<String>) {
        val key = geminiKey
        if (key.isBlank()) return
        speechExec.execute { texts.forEach { fetchAudio(key, it) } }
    }

    private fun fetchAudio(key: String, text: String): GeminiTts.Audio? {
        synchronized(cache) { cache[text]?.let { return it } }
        val a = GeminiTts.synth(key, text, prefs) ?: return null
        synchronized(cache) { cache[text] = a }
        return a
    }

    private fun play(a: GeminiTts.Audio, myGen: Int) {
        var t: AudioTrack? = null
        try {
            t = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(a.rate)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(a.pcm.size - a.pcm.size % 2)
                .setTransferMode(AudioTrack.MODE_STATIC)
                .build()
            track = t
            t.write(a.pcm, 0, a.pcm.size - a.pcm.size % 2)
            t.play()
            val frames = a.pcm.size / 2
            val deadline = System.currentTimeMillis() + frames * 1000L / a.rate + 2500
            while (gen.get() == myGen && t.playbackHeadPosition < frames &&
                System.currentTimeMillis() < deadline
            ) {
                Thread.sleep(40)
            }
        } catch (e: Exception) {
            // awaaz na chale to chup chaap aage barho
        } finally {
            try { t?.stop() } catch (e: Exception) {}
            try { t?.release() } catch (e: Exception) {}
            if (track === t) track = null
        }
    }

    private fun speakAndroid(text: String, finish: () -> Unit) {
        if (!ttsReady) { finish(); return }
        val id = System.nanoTime().toString()
        callbacks[id] = finish
        tts?.speak(text, TextToSpeech.QUEUE_ADD, null, id)
    }

    /** Bolna shuru: sunna roko. Wapas aane wala finish() ek hi baar chalta hai. */
    private fun beginSpeech(onDone: () -> Unit): () -> Unit {
        speaking++
        try { recognizer?.cancel() } catch (e: Exception) {}
        val done = AtomicBoolean(false)
        val finish: () -> Unit = {
            if (done.compareAndSet(false, true)) {
                main.post {
                    speaking = maxOf(0, speaking - 1)
                    if (speaking == 0) restartSoon(300)
                }
                onDone()
            }
        }
        // Safai: kisi wajah se jawab na aaye to 45 second baad sunna dobara shuru.
        main.postDelayed({ finish() }, 45_000)
        return finish
    }

    // ---------- Sunna rokna / dobara shuru karna (jab MJ kaam kar rahi ho) ----------
    fun setSuspended(value: Boolean) {
        suspended = value
        if (value) {
            main.removeCallbacks(startRunnable)
            try { recognizer?.cancel() } catch (e: Exception) {}
        } else if (continuous) {
            restartSoon(200)
        }
    }

    // ---------- Lagataar sunna ----------
    fun startContinuous() {
        if (continuous) return
        continuous = true
        restartSoon(0)
    }

    fun stopContinuous() {
        continuous = false
        main.removeCallbacks(startRunnable)
        try { recognizer?.destroy() } catch (e: Exception) {}
        recognizer = null
    }

    private fun restartSoon(delayMs: Long) {
        main.removeCallbacks(startRunnable)
        main.postDelayed(startRunnable, delayMs)
    }

    private fun startListening() {
        if (!continuous || suspended || speaking > 0) return
        if (!SpeechRecognizer.isRecognitionAvailable(ctx)) {
            onInfo("Is phone par speech recognition maujood nahi.")
            return
        }
        try { recognizer?.destroy() } catch (e: Exception) {}
        val r = SpeechRecognizer.createSpeechRecognizer(ctx)
        r.setRecognitionListener(object : RecognitionListener {
            override fun onResults(results: Bundle?) {
                val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (!text.isNullOrBlank()) onHeard(text)
                restartSoon(250)
            }

            override fun onError(error: Int) {
                if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
                    continuous = false
                    onInfo("Mic ki ijazat nahi mili. App ki settings mein Microphone allow karo.")
                    return
                }
                // 6 = kuch bola nahi, 7 = samajh nahi aaya: ye normal hain, foran dobara sunna.
                val quick = error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT || error == SpeechRecognizer.ERROR_NO_MATCH
                restartSoon(if (quick) 150 else 1500)
            }

            override fun onReadyForSpeech(p: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rms: Float) {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(p: Bundle?) {}
            override fun onEvent(t: Int, p: Bundle?) {}
        })
        recognizer = r

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ur-PK")
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, ctx.packageName)
            // Bolne ke beech thori khamoshi par foran na rukna (sab phones par kaam nahi karta).
            putExtra("android.speech.extra.SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS", 2000L)
            putExtra("android.speech.extra.SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS", 1500L)
        }
        r.startListening(intent)
    }

    fun shutdown() {
        gen.incrementAndGet()
        speechExec.shutdownNow()
        stopContinuous()
        main.removeCallbacksAndMessages(null)
        tts?.shutdown()
    }
}
