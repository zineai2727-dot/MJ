package com.waqas.mj

import android.content.SharedPreferences
import android.util.Base64
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * Gemini ki zinda awaaz (Sulafat). Google do tareeqe/naam rakhta hai, is liye pehli baar
 * sab aazmati hai, jo chal jaye usay yaad rakhti hai. Na chale to null deti hai
 * (tab Android ki awaaz backup mein bolti hai).
 */
object GeminiTts {

    class Audio(val pcm: ByteArray, val rate: Int)

    const val VOICE = "Sulafat"
    private const val STYLE =
        "Speak in Urdu, in a warm, loving, cheerful and caring female voice, like a close friend:"
    private const val BASE = "https://generativelanguage.googleapis.com/v1beta"

    private val MODELS = listOf(
        "gemini-3.8-flash-tts",
        "gemini-3.8-flash-lite-tts",
        "gemini-3.1-flash-tts-preview",
        "gemini-2.5-flash-preview-tts"
    )

    private val client = OkHttpClient.Builder()
        .callTimeout(25, TimeUnit.SECONDS)
        .build()

    @Volatile
    private var blockedUntil = 0L

    private class Attempt(val audio: Audio?, val code: Int)

    fun synth(apiKey: String, text: String, prefs: SharedPreferences): Audio? {
        if (System.currentTimeMillis() < blockedUntil) return null

        val cached = prefs.getString("tts_combo", null)
        val combos = if (cached != null) listOf(cached)
        else MODELS.flatMap { listOf("$it|interactions", "$it|generate") }

        var lastCode = 0
        for (combo in combos) {
            val model = combo.substringBefore("|")
            val method = combo.substringAfter("|")
            val a = try {
                if (method == "interactions") viaInteractions(apiKey, model, text)
                else viaGenerate(apiKey, model, text)
            } catch (e: Exception) {
                Attempt(null, 0)
            }
            if (a.audio != null) {
                if (cached != combo) {
                    prefs.edit().putString("tts_combo", combo).apply()
                    LogBus.log("Gemini awaaz chal gayi ($model, $method, $VOICE).")
                }
                return a.audio
            }
            lastCode = a.code
        }

        // Fail hua: thori der dobara koshish na karo, warna har jumla slow hoga.
        if (cached != null && (lastCode == 400 || lastCode == 404)) {
            prefs.edit().remove("tts_combo").apply() // model badal gaya ho to agli baar phir dhoondo
        }
        LogBus.log("Gemini awaaz nahi bani (error $lastCode), Android awaaz chal rahi hai.")
        val pause = if (lastCode == 401 || lastCode == 403) 300_000L else 20_000L
        blockedUntil = System.currentTimeMillis() + pause
        return null
    }

    private fun post(url: String, apiKey: String, body: JSONObject): Pair<Int, String> {
        val req = Request.Builder()
            .url(url)
            .header("x-goog-api-key", apiKey)
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .build()
        client.newCall(req).execute().use { r -> return Pair(r.code, r.body?.string().orEmpty()) }
    }

    private fun viaInteractions(apiKey: String, model: String, text: String): Attempt {
        val body = JSONObject()
            .put("model", model)
            .put(
                "input",
                JSONArray().put(
                    JSONObject().put("type", "user_input").put(
                        "content",
                        JSONArray().put(JSONObject().put("type", "text").put("text", "$STYLE $text"))
                    )
                )
            )
            .put("response_format", JSONObject().put("type", "audio"))
            .put(
                "generation_config",
                JSONObject().put("speech_config", JSONArray().put(JSONObject().put("voice", VOICE)))
            )
        val (code, raw) = post("$BASE/interactions", apiKey, body)
        return Attempt(if (code in 200..299) parse(raw) else null, code)
    }

    private fun viaGenerate(apiKey: String, model: String, text: String): Attempt {
        val body = JSONObject()
            .put(
                "contents",
                JSONArray().put(
                    JSONObject().put("parts", JSONArray().put(JSONObject().put("text", "$STYLE $text")))
                )
            )
            .put(
                "generationConfig",
                JSONObject()
                    .put("responseModalities", JSONArray().put("AUDIO"))
                    .put(
                        "speechConfig",
                        JSONObject().put(
                            "voiceConfig",
                            JSONObject().put(
                                "prebuiltVoiceConfig", JSONObject().put("voiceName", VOICE)
                            )
                        )
                    )
            )
        val (code, raw) = post("$BASE/models/$model:generateContent", apiKey, body)
        return Attempt(if (code in 200..299) parse(raw) else null, code)
    }

    // ---------- Jawab se audio nikalna ----------
    private fun parse(raw: String): Audio? {
        val json = try { JSONObject(raw) } catch (e: Exception) { return null }
        val found = findAudio(json) ?: return null
        val bytes = try {
            Base64.decode(found.first.replace('-', '+').replace('_', '/'), Base64.DEFAULT)
        } catch (e: Exception) {
            return null
        }
        if (bytes.size < 100) return null

        // WAV ho (RIFF) to header hata kar asli awaaz aur sample rate nikalo.
        if (bytes[0] == 'R'.code.toByte() && bytes[1] == 'I'.code.toByte() &&
            bytes[2] == 'F'.code.toByte() && bytes[3] == 'F'.code.toByte()
        ) {
            val rate = (bytes[24].toInt() and 0xFF) or ((bytes[25].toInt() and 0xFF) shl 8) or
                ((bytes[26].toInt() and 0xFF) shl 16) or ((bytes[27].toInt() and 0xFF) shl 24)
            var i = 12
            while (i + 8 < bytes.size) {
                val isData = bytes[i] == 'd'.code.toByte() && bytes[i + 1] == 'a'.code.toByte() &&
                    bytes[i + 2] == 't'.code.toByte() && bytes[i + 3] == 'a'.code.toByte()
                if (isData) {
                    return Audio(bytes.copyOfRange(i + 8, bytes.size), if (rate in 8000..48000) rate else 24000)
                }
                val size = (bytes[i + 4].toInt() and 0xFF) or ((bytes[i + 5].toInt() and 0xFF) shl 8) or
                    ((bytes[i + 6].toInt() and 0xFF) shl 16) or ((bytes[i + 7].toInt() and 0xFF) shl 24)
                if (size < 0) break
                i += 8 + size
            }
            return Audio(bytes.copyOfRange(44, bytes.size), if (rate in 8000..48000) rate else 24000)
        }

        // Warna seedha PCM (16-bit mono), aam taur par 24000 Hz.
        val rate = Regex("rate=(\\d+)").find(found.second)?.groupValues?.get(1)?.toIntOrNull() ?: 24000
        return Audio(bytes, rate)
    }

    /** JSON mein kahin bhi chhupi hui lambi base64 audio dhoondo. Pair(data, mimeType). */
    private fun findAudio(node: Any?): Pair<String, String>? {
        when (node) {
            is JSONObject -> {
                val keys = node.keys()
                while (keys.hasNext()) {
                    val k = keys.next()
                    val v = node.opt(k)
                    if (v is String && v.length > 2000 &&
                        v.take(200).all { it.isLetterOrDigit() || it in "+/=_-\n\r " }
                    ) {
                        return Pair(v, node.optString("mime_type", node.optString("mimeType", "")))
                    }
                    val f = findAudio(v)
                    if (f != null) return f
                }
            }
            is JSONArray -> {
                for (i in 0 until node.length()) {
                    val f = findAudio(node.opt(i))
                    if (f != null) return f
                }
            }
        }
        return null
    }
}
